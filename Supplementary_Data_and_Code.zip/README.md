# Supplementary source data and plotting code

This archive accompanies the manuscript “Waiting time reverses re-pressurization yield rankings in polymer hydrogen-storage liners”. It contains existing plotted-data extracts, tabulated spatial data, numerical-verification summaries, provenance records and plotting scripts. No new mechanical or transport simulation was performed for this submission closeout.

## Contents

- data/plotted_data_and_provenance.json: data used for the final figures and hashes of the original numerical input records.
- data/spatial/: archived spatial figure data as CSV files.
- verification/: existing CSV/JSON comparisons, independent benchmark records and reproduction notes supplied with the manuscript.
- plotting/: Python scripts used in figure preparation. These scripts require Python, NumPy, SciPy, Matplotlib, Pillow and PyMuPDF; Times New Roman/STIX fonts are used by the figure styles. Paths follow the original research-workspace layout.
- MANIFEST.json: byte sizes and SHA-256 hashes of the supplied files.

The plotting scripts are provided as source records; they are not a standalone simulator and may require original workspace records not included here. This archive does not contain the full mechanical solver or raw preparation/waiting state checkpoints. The manuscript's data-and-code statement leaves their verified access route and any restrictions for the authors to complete. No repository identifier or on-request release commitment is asserted.

The separately supplied figure bundle contains the vector/raster artwork. The supplementary methods describe the physical problem, numerical checks and source archive identifiers.
