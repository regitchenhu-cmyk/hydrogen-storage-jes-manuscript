# Full-history transient pore-exchange verification

This numerical extension tests the fixed-conductance approximation while retaining the original pressure program, cylinder, mechanical constitutive law, wall-diffusion bath and pore geometry. It is implemented in new Round23 files; the Round21/22 solver and archives are preserved.

## Formulation

Let the imposed local bath pressure be pi_b(t), the pore pressure p_g(t), and delta(t)=pi_b(t)-p_g(t). For a fixed spherical pore of radius a in an infinite surrounding medium, the local concentration perturbation follows spherical diffusion with zero initial perturbation and zero far-field perturbation. The background is supplied by the macroscopic wall solution: its local time derivative is imposed as background forcing. A spatially uniform, time-varying concentration is not asserted to solve source-free diffusion by itself.

The exact boundary influx, in the inventory units N=nRT, is

```
dN/dt = L [ delta(t) + a/sqrt(pi D) integral_0^t delta_dot(s)/sqrt(t-s) ds ],
L = 4 pi a D R T S.
```

The octant uses one-eighth of L and pore volume, as in the baseline. The convolution is integrated analytically over each piecewise-linear pressure-difference segment. Endpoint backward Euler couples the resulting flux to N=p_g V. Its implicit pressure coefficient is positive, 1+2a/sqrt(pi D dt). Historical contributions are retained from ambient through the entire preparation, waiting and recharge. Independent recharge copies and fractional first-yield trials preserve the same complete diffusion history.

This fixed-radius infinite-medium kernel introduces no finite radial-domain truncation or radial diffusion mesh. The retained approximation is the dilute, prescribed-background local superposition and fixed reference pore radius. The mechanically computed pore volume still determines gas pressure and feeds back into flux.

The existing mechanical solver is reused through an algebraic effective bath and positive volume offset. Its effective-bath chemical-work ledger is only an algebraic solve check: no physical total-energy or entropy balance for the transient diffusion field is claimed. The independent physical check is the pore inventory increment against the actual history-dependent flux.

## Independent checks

- Step, ramp and signed multisegment convolution agree with closed forms or independent quadrature to below 1e-10 in the kernel checks.
- For a unit step in pressure difference, average conductance during a 1.81393 s preparation leg is 2.790286 times the quasi-steady conductance. This is a kernel diagnostic, not an assumed multiplier applied to the actual evolving pressure difference.
- A fixed-volume coupled ramp is checked against an independent Laplace/erfcx solution. At 18.1393 s the reference pore pressure is 1.58954814 MPa. With 40, 80, 160, 320 and 640 steps, absolute errors are 0.0287018, 0.0144532, 0.00726156, 0.00364283 and 0.00182559 MPa, showing first-order time convergence.
- Shifting the same test by 548000 s changes the 160-step answer by only 5.36e-11 MPa, checking long-clock cancellation handling.
- Complete-memory clone and uncommitted-candidate checks pass. Prepared memory begins at ambient and reaches the full preparation endpoint without a reset.

## Coupled coarse-mesh comparison

Both exchange laws are solved from virgin ambient equilibrium, with identical pressure/traction controls and the canonical waiting nodes. Tests at 0, 40, 300, 1800 and 7200 s use the same recharge ramp. The second resolution halves every preparation, waiting and recharge increment, including long fill/hold increments and short decompression/pulse increments.

The maximum absolute transient-minus-quasi-steady threshold correction is 0.0624587 MPa at the base time resolution and 0.0635386 MPa after complete time refinement. The paired correction changes by at most 0.00107989 MPa under refinement. Ranking signs are preserved at all five compared times on this mechanical mesh.

The maximum within-model threshold change under complete time refinement is 0.12625 MPa. This check has broader scope than the previous 0.05672 MPa check, which refined waiting and recharge from fixed preparation checkpoints; the two must not be substituted for each other.

After refined preparation, transient exchange changes inventory by +0.0240295% for A and +0.0132969% for B, with pore-pressure shifts of +0.00810417 and +0.00447805 MPa. Thus, a sizable short-time kernel enhancement does not imply a comparable threshold change: the actual pressure mismatch evolves, and only a small inventory correction accumulates during the short preparation.

The matched quasi-steady replay reproduces the archived canonical Round22 baseline within 4e-11 MPa. The transient accepted records retain positive gas pressure, pore volume, physical bath pressure and algebraic effective bath. Maximum physical memory-flux inventory residual is below 1.5e-16 in E0 a^3 units.

## Fine-mesh confirmation

The additional 8x6x6 mechanical-mesh campaign completed ten transient readouts from newly generated ambient-to-preparation histories. The matched quasi-steady comparator uses the canonical Round22 fine waiting schedule, with the zero-wait readout from the same original preparation. The five transient A-minus-B differences are:

| Waiting time / s | Transient A threshold / MPa | Transient B threshold / MPa | Transient difference / MPa |
|---:|---:|---:|---:|
| 0 | 29.513939 | 18.722936 | +10.791003 |
| 40 | 22.044241 | 22.518837 | -0.474596 |
| 300 | 12.880757 | 14.398794 | -1.518037 |
| 1800 | 11.151351 | 10.841948 | +0.309403 |
| 7200 | 27.714208 | 25.203976 | +2.510232 |

All five ranking signs match the quasi-steady reference. The maximum individual threshold correction is 0.0899423 MPa, at A after 40 s. In that comparison the canonical reference is 22.1341828 MPa; the separate fine-hotspot archive has a slightly different preceding time-node schedule and must not replace this matched comparator. The full coarse and fine calculations therefore preserve the positive-negative-positive sequence under the transient extension. This is a tested reference-case result, not a universal error bound for every pore radius or loading history.

The prepared fine-mesh inventory changes are +0.0242777% for A and +0.0137413% for B. Across the five new campaigns, fifty additional thresholds were evaluated: two transport laws and two full-time resolutions on the coarse mesh, plus transient transport on the fine mesh.

## Sources

Machine-readable data are in `screening/transient_comparison_summary_round23.json`, with a flat CSV companion. `screening/transient_coupled_audit_round23.json` records the coupled checks and source hashes. `screening/transient_kernel_independent_reference_round23.json` stores the independent kernel/ramp test. Full preparation records, waiting records, readout records and restart checkpoints are under `mechanics/transient_*_round23*`.

The mechanical meshes are not claimed to be continuum-converged by this transport comparison. Their separate refinement campaign addresses that issue.
