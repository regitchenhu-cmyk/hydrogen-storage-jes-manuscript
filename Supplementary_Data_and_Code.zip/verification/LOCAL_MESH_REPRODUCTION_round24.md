# Round24 local-refinement campaign

The radial family preserves the original `12x8x8` curved mesh outside `rho/a=2`. L1 bisects each of its first four radial shells; L2 quarters those same shells. The resulting meshes contain 1,024 and 1,536 elements. Radial Q2 midside nodes remain arithmetic means. All original radial boundaries, angular nodes, pore/outer surfaces and reference volumes are retained. The separate L1A10 control keeps L1's radial edges and uses uniform `10x10` angular elements (1,600 total); it changes angular resolution and the curved-boundary approximation together and is not an angular nested family.

`local_pore_round24.py` inherits the original constitutive, gas-exchange, candidate, Newton/line-search, energy and commit methods. Its constructor and checkpoint loader add explicit radial-edge identity. Every new mesh starts from virgin relaxed ambient equilibrium and solves the complete original preparation; no material-history field is interpolated. The immutable linear elastic operator is shared only among identical meshes within a process. The recorded sparse ordering is `MMD_AT_PLUS_A`, independently checked against the original ordering in `sparse_ordering_benchmark_round24.json`; no tolerance or numeric-pivoting setting changes.

Run each common preparation before its two independent branches:

```powershell
python mechanics/local_mesh_campaign_round24.py --level 1 --stage common
python mechanics/local_mesh_branch_round24.py --level 1 --amp 10
python mechanics/local_mesh_branch_round24.py --level 1 --amp 40
python mechanics/local_mesh_observations_round24.py --level 1 --amp 10
python mechanics/local_mesh_observations_round24.py --level 1 --amp 40
```

Repeat with `--level 2` for L2. A/B branches can run concurrently after their common JSON reports `status=complete`. Observation workers require their corresponding branch to be complete. Output labels distinguish `local_L1_round24`, `local_L2_round24` and `local_L1A10_round24`.

The executed L1A10 branches use `local_angular_fast_branch_round24.py`; their later observation loads use `local_angular_fast_observations_round24.py`. These separate hashed derivatives additionally select MMD for the immutable elastic LU cache before model construction. The independent `constant_elastic_ordering_benchmark_round24.json` compares identical matrices and continuous actual pulse steps with both orderings. Active L1/L2 runs and all active preparation sources were not changed.

```powershell
python mechanics/local_angular_campaign_round24.py --level 1 --stage common
python mechanics/local_angular_fast_branch_round24.py --level 1 --amp 10
python mechanics/local_angular_fast_branch_round24.py --level 1 --amp 40
python mechanics/local_angular_fast_observations_round24.py --level 1 --amp 10
python mechanics/local_angular_fast_observations_round24.py --level 1 --amp 40
```

L2's initial B threshold differs from L1 by 0.34394 MPa, exceeding the predeclared 0.1 MPa practical criterion. This triggered the additional L3 campaign, which subdivides the same four original inner shells into eight parts (40 radial layers, 2,560 elements). Its geometry preflight is `extra_geometry_L3_round24.json`. Commands use `local_deep_campaign_round24.py --level 3 --stage common`, followed by `local_deep_fast_branch_round24.py --level 3 --amp 10` / `40` and the corresponding `local_deep_fast_observations_round24.py`. The original L1/L2 edge generator and active sources remain unchanged.

All canonical held states are saved. Eight additional observation states are the nearest existing accepted steps to 90, 120, 180, 240, 420, 600, 900 and 1,200 seconds. The branch driver saves both endpoints of each original bracket and selects the nearest; the observation worker checks exact agreement with the archived schedule and probes a clone. Neither an inserted waiting node nor a fractional waiting substep is used. Before/after physical-state digests verify that readouts do not change the held history.

The executed L3 readouts overlap the main holding path. After a history commits its 300 s held checkpoint, run `python mechanics/local_staged_observations_round24.py --amp 10 --stage early` for the first four saved observations. After the 1,800 s held checkpoint, run the same command with `--stage late` for the remaining four. Repeat for amplitude 40. Each batch captures an immutable byte copy of the committed branch manifest and checks each held checkpoint's file hash and state digest before and after probing. Once that history and both batches report completion, `--stage merge` checks every selected record and hash against the final branch, then writes the ordinary observations JSON. Use this staged route or the complete-branch observation driver, not both. An independent rerun of a completed angular observation with the staged worker reproduces the entire original first-root and maximizing-point records exactly (`staged_observation_equivalence_round24.json`).

Common preparation and branch outputs are separate and checkpointed. On an interrupted common run, verify that the checkpoint SHA matches its manifest and that its physical clock equals the source record at `next_index-1` before resuming; a mismatch indicates an interrupted multi-file checkpoint write and must not be stepped forward. Branch preparation checks source clock and explicit radial edges on resume. Numerical integrity and practical-resolution outcomes are reported separately by the independent Round24 audit.

Geometry/constructor checks: `local_mesh_checks_round24.json` and `angular_control_geometry_round24.json`. Primary raw archives: `mechanics/local_L*_round24_common.json`, `mechanics/local_L*_round24_pulse10.json` and `pulse40.json`; added observations append `_observations.json` to each branch stem.

The independent `screening/lame_yield_sampling_round24.py` benchmark prescribes an internal pressure increment in a virgin elastic spherical shell. It compares the analytical first-yield pressure at the true wall, the analytical pressure evaluated at the mesh's Gauss points and the FE first-yield pressure. This separates radial sampling from FE stress error for that analytically tractable problem. It neither changes the Gauss-point criterion on the prepared histories nor extrapolates their thresholds to the wall.

The planned study is complete: each of L1, L2, L3 and L1A10 has seven canonical and eight added accepted-node readouts for each of A and B. Together with the matching R0 baseline, this gives 75 sampled pressure-window pairs. The largest L2-to-L3 absolute threshold change is 0.368038 MPa (B at 60 s); 13 of 30 individual changes are at most 0.1 MPa. The corresponding two endpoints at 7,200 s both change by less than 0.1 MPa. Use the complete independent audit and its stated criteria for resolution of an interval or ranking; the 75 pairs are finite-mesh comparisons, not continuum bounds.

No L4 or crossed angular campaign was run. A possible follow-up for a specifically wall-controlled question would bisect L3's cells in the first original shell (`rho/a <= 1.189207115`) while retaining its other cells. This would give 48 radial layers rather than 72 for bisecting the entire previously refined region. A controlling point in that shell does not establish that bulk or angular errors are negligible; the angular control demonstrates appreciable sensitivity at intermediate holds.
