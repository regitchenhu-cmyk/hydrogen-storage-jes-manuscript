# Independent review of Round23 numerical verification

This author-side numerical-methods review covers the completed third-mesh full-history calculation and transient spherical exchange extension. It performs no new finite-element equilibrium solve. Independent scalar transport calculations, checkpoint-state checks, raw-source comparisons and a separately reconstructed Q2 field integral are included below.

## Formulation review

The transient extension removes the quasi-steady-in-time local exchange approximation while retaining the original dilute, infinite-sphere matching geometry. Let the local perturbation be `w=c/S−π_b(t)`, with wall value `w(a,t)=p_g−π_b` and zero perturbation at infinity. The prescribed macroscopic bath provides the locally uniform time-dependent background; it is not a globally uniform, source-free diffusion solution. With this background interpretation, the perturbation obeys the radial diffusion equation.

For initially uniform ambient equilibrium, the resulting influx is

`J=−L[w(a,t)+(a/√(πD)) ∫₀ᵗ (∂w(a,s)/∂s)/√(t−s) ds]`.

This expression follows independently by solving the Laplace-transformed radial equation for `r w`, which gives the boundary transfer factor `1+√(a²s/D)`. The production module evaluates the history convolution exactly for each continuous piecewise-linear boundary segment and couples its endpoint flux to gas inventory with backward Euler. Algebraic elimination yields a positive current pressure coefficient and the existing nonlinear gas-volume solve. The signed history term cannot be replaced by a clock-reset multiplier.

The code correctly keeps actual bath pressure separate from the algebraic effective bath. Its inherited endpoint energy ledger is explicitly labelled as an algebraic effective-bath identity, not a physical energy balance including the transient diffusion field. Similarly, the sign of instantaneous `π_b−p_g` alone does not determine flux once diffusion memory is present. These distinctions must remain in the manuscript integration.

## Independent transport checks

`transient_kernel_independent_reference_round23.py` obtains a separate fixed-volume gas response from analytic Laplace inversion. For a unit-rate bath-pressure ramp, the bath-minus-pore step response is inverted using the two conjugate roots in `√s` and the scaled complementary error function; adaptive quadrature then gives the ramp response. No production history quadrature is used to construct that reference.

At `t=0.1 τ_p=18.1393187658 s`, the reference pressure is `1.58954813559 MPa` for a bath `0.1+t MPa`. The production memory coefficients combined with a separate fixed-volume inventory update give errors of `0.0287018`, `0.0144532`, `0.00726156`, `0.00364283` and `0.00182559 MPa` for 40, 80, 160, 320 and 640 steps. Error ratios approach two, consistent with first-order endpoint integration. The maximum scalar inventory residual is below `3×10⁻¹⁶ MPa`. Shifting an initially zero perturbation history by 548000 s changes the 160-step pressure by only `5.36×10⁻¹¹ MPa`, checking numerical cancellation after long preparation.

The independent checkpoint check loads the newly prepared transient A state. Its 225 history nodes start at ambient time and end at the current mechanical time. Candidate calls at increments 0, `10⁻⁸` and `10⁻³` in `t/τ_p` preserve the bytes of all internal fields, gas inventory and history arrays. Mutating the history arrays of a clone does not change the original. Evidence is in `transient_clone_audit_round23.json`.

## Driver and comparison review

The mesh verification uses a new `12×8×8` pore mesh with the same outer radius `8a`, quadratic elements, 27 quadrature points per element and physical material parameters. It replays the entire ambient, filling, holding and release history before independently branching into the two axial preparations. No plastic-field interpolation is used. Waiting lands on the same canonical nodes as Round22, and independent recharging copies stop at the first admissibility crossing. First-critical coordinates and regions are retained.

The transient comparison also regenerates the full preparations separately for each transport model and time resolution. Subdivision of preparation increments advances both the macroscopic solution and local diffusion history. Waiting and readout use the same refinement factor. The independent re-run of the quasi-steady model at the original resolution reproduces all ten matched Round22 coarse-mesh thresholds at waits 0, 40, 300, 1800 and 7200 s to a maximum difference of `3.90×10⁻¹¹ MPa`.

The third-mesh comparison should be reported as a discretization sensitivity study unless the actual sequence justifies an asymptotic convergence estimate. A maximum-over-quadrature first-yield quantity may change controlling locations with refinement. Agreement of ranking alone does not establish convergence of absolute pressure.

## Completed transport full-history comparison

All four coarse-mesh campaigns are complete: quasi-steady and transient exchange at the original and halved time increments. Each includes separate complete A and B preparations and five independent recharging tests per history (0, 40, 300, 1800 and 7200 s), giving 40 thresholds.

| Quantity | Independently recomputed value |
|---|---:|
| Largest transient-minus-quasi-steady individual-pressure shift, original increments | 0.062458745 MPa |
| Same quantity, halved increments | 0.063538640 MPa |
| Largest change in the paired transport correction after halving | 0.001079894 MPa |
| Largest absolute pressure change from full-history time halving, quasi-steady | 0.126247823 MPa |
| Same quantity, transient | 0.126240335 MPa |
| Largest original-resolution quasi-steady regression error versus Round22 | 3.9048×10⁻¹¹ MPa |

The largest paired transport correction occurs for A at 40 s. Full-history time refinement changes preparation as well as waiting and recharging; its 0.126 MPa absolute sensitivity is therefore distinct from the earlier 0.05672 MPa check that held preparation fixed. The transport-model correction itself is stable to approximately 0.00108 MPa under this stricter refinement.

Both transport models at both resolutions retain positive, negative and positive A-minus-B differences at 0, 300 and 7200 s. For transient exchange with halved increments these differences are +10.5811, −0.6362 and +1.8966 MPa. This supports persistence of the sampled double reversal under the tested transport extension; it does not establish an exact crossover time.

The independent scan includes 1259 and 2495 accepted transient records, counting the shared preparation records retained within each history. The largest transient inventory residual is 1.4442×10⁻¹⁶ in the solver's `E₀a³` normalization; the largest normalized force residual is 1.9772×10⁻⁹. Physical pore pressure, actual bath pressure and algebraic effective bath pressure are positive in every record. The largest absolute threshold root residual is 6.2186×10⁻¹¹ MPa. The audit deliberately does not reinterpret the algebraic effective-bath energy ledger as a physical diffusion-field energy balance.

`verification_review_round23.json` contains the ten paired rows, residual summaries, checks and SHA-256 records. The completed third-mesh review is reported below; all seven waiting times now contain both histories.

The prepared-state comparisons explain why the short-time kernel correction remains small in this protocol. At the refined resolution, transient exchange changes gas inventory by +0.02403% for A and +0.01330% for B, with pore-pressure shifts of +0.00810 and +0.00448 MPa. These are actual paired preparation results. The isolated concentration-step average conductance multiplier of 2.79 over one pulse leg is therefore not itself a threshold-error estimate: the applied leg lasts only 0.01 `τ_p`, and the actual gas/bath pressure difference is small. The data support this protocol-specific explanation without implying that transient diffusion is always negligible.

## Fine-mesh transient confirmation

The additional complete transient preparation and ten recharging tests on the `8×6×6` mesh are also independently checked. The maximum absolute pressure correction is **0.089942289 MPa**, again for history A at 40 s. Comparisons at 40, 300, 1800 and 7200 s use the canonical Round22 normal-readout baseline; the zero-wait comparison uses the original fine preparation and Round21 root. This avoids mixing the canonical 40 s value of 22.134182829 MPa with the separately sampled hotspot trajectory value, which differs by about 0.000167 MPa.

| Waiting time / s | Quasi-steady A−B / MPa | Transient A−B / MPa |
|---:|---:|---:|
| 0 | +10.810652 | +10.791003 |
| 40 | −0.394437 | −0.474596 |
| 300 | −1.502972 | −1.518037 |
| 1800 | +0.309226 | +0.309403 |
| 7200 | +2.499352 | +2.510232 |

The five sampled signs are preserved. Across 1217 accepted records, including shared preparation records, the largest normalized transient inventory residual is 4.8754×10⁻¹⁶, the largest force residual is 1.8717×10⁻⁹, and the largest absolute root residual is 5.5308×10⁻¹¹ MPa. All pore, actual bath and effective bath pressures remain positive. Coarse-grid full-time refinement and fine-grid transport confirmation address different errors; they should not be merged into a single convergence percentage.

## Completed third-mesh review

The seven-time campaign is complete: independently prepared A and B states on the 768-element mesh were probed at 0, 40, 60, 300, 1800, 7200 and 146118.72146 s. Matched coarse/fine early and late controls remove small output-schedule differences. The independent portable audit passes 566 raw-source checks before manuscript integration. All baseline, source-hash, interval, residual and coverage checks pass.

| Waiting time / s | Coarse A−B / MPa | Fine A−B / MPa | Refined A−B / MPa | Refined A / MPa | Refined B / MPa |
|---:|---:|---:|---:|---:|---:|
| 0 | +10.750802 | +10.810652 | +10.454240 | 29.300637 | 18.846397 |
| 40 | +1.176897 | -0.394437 | -1.331874 | 21.254684 | 22.586558 |
| 60 | -0.472014 | -1.323885 | -0.848429 | 20.071636 | 20.920065 |
| 300 | -0.624318 | -1.502972 | +0.329735 | 13.332929 | 13.003194 |
| 1800 | -0.990583 | +0.309226 | -1.197519 | 10.295781 | 11.493300 |
| 7200 | +1.901683 | +2.499352 | +1.928483 | 26.879756 | 24.951273 |
| 146119 | +4.871693 | +4.675690 | +4.582022 | 22.882576 | 18.300553 |

Every tested mesh retains repeated ranking changes, and all three show positive, negative and positive differences at 0, 60 and 7200 s. The refined sequence over all seven samples is `+ − − + − + +`, giving four observed sign changes; coarse and fine each give two. These counts are lower bounds from the sampled trajectories, not exact continuum crossing counts. In particular, the refined ranking reverses the fine result at both 300 and 1800 s. The paper must therefore distinguish the reference two-reversal example from the mesh-tested finding of repeated reversals.

The largest fine-to-refined pressure change is 1.449794150 MPa (10.0311033% of the fine threshold), for B at 300 s. Refinement is nonmonotone and nonuniform: A at 300 s contracts from a 4.302850 MPa coarse–fine difference to 0.382913 MPa, but A at 7200 s grows from 0.120451 to 0.819632 MPa. Both fine and refined A/B onset points at 300 s remain in region M; their near-surface coordinates and local preparation fields differ. The data do not support a single monotone extrapolation or Richardson/GCI error bound.

The all-three A-favoring intervals, computed before rounding, are `(19.440440,29.300637)` MPa at 0 s, `(25.918156,26.879756)` MPa at 7200 s, and `(21.365187,22.882576)` MPa at 146118.72146 s. Thus 22 MPa is a valid common distinguishing terminal pressure initially and late, and lies below both 2 h thresholds. The old 23 MPa late example is invalid on the refined mesh. At 60 s all three favor B but their intervals have no common intersection; the fine/refined-only B interval is `(20.418902,20.920065)` MPa. At 300 s neither ranking nor pressure interval agrees across all three.

Plastic memory is independently confirmed with a fresh Q2 geometric integration: nodal spherical coordinates and tensor-product Lagrange derivatives reconstruct all 20,736 Jacobian-weighted integration points without importing the production geometry class or assembling stiffness. The refined RMS contrast changes from 0.000191283444815 to 0.000183978996093, retaining 96.181348193% at 40.59 h. This agrees with the production extraction to machine precision. Evidence is in `mesh_memory_independent_round23.py/json`.

Publication-level scope: the verified result is repeated, mesh-sensitive ranking changes with persistent plastic memory. The reference-grid sequence survives the full-history transient transport extension, with maximum tested correction 0.089942289 MPa. Spatial refinement changes intermediate stages and the observed count; it does not erase the repeated-reversal phenomenon or the three reported common A-favoring pressure intervals. The new transient runs validate unmodified coupled trajectories; the freeze/Shapley attribution remains the original quasi-steady baseline experiment.

## Final publication checks

The completed manuscript passes 797 portable source/claim checks and 1243 checks in the full v3 audit, retaining the original 241 baseline check calls. New supplementary Tables S4–S7, both continued S4 tables, all interval statements, updated abstract/conclusions, figures, equations and references are included. Actual rendered main PDF pages 20–29 were visually inspected: no clipping, overlap, unreadable figure labels or source-value inconsistency was found. The page images and QA note are bound to PDF SHA-256 `8c4908a948d50d958b6ae6d6af47848b1a1e08edb866ddca7b610548862526f9`.
