# Final figure bundle

Eight main figures and five supplementary figures, each in PDF/SVG/600 dpi PNG/LZW TIFF. Times New Roman and STIX, 180 mm master width; enlarged label sizes retained. JSON records contain plotted values, source hashes, renumbering, export checks and actual visual reviews. No new numerical simulation was run.

The plotting scripts require the original research workspace and archived mechanics/screening data. This ZIP contains artwork and plotted-data extracts, not all raw state files or a standalone simulator. Relative paths identify the original workspace layout. Use the PDF masters for LaTeX.
