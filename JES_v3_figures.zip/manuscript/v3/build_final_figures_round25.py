"""Final manuscript figures from completed archived calculations.

Uses the established Python/Matplotlib workflow only. This script renders stored
records and saved fields; it performs no equilibrium or time-evolution solve.
The original thirteen-figure masters remain unchanged.
"""
from pathlib import Path
import argparse, csv, hashlib, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
from matplotlib.lines import Line2D
import build_publication_figures as general
import build_local_refinement_figures_round24 as local
import build_verification_figures_round23 as transport
import build_spatial_figures as spatial

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'manuscript/figures_final';OUT.mkdir(parents=True,exist_ok=True)
SPATIAL=OUT/'spatial_data';SPATIAL.mkdir(exist_ok=True)
MAPPING={
 'fig01_protocol':'fig01_protocol','fig03_thresholds':'fig02_thresholds',
 'fig04_spatial_yield':'fig03_spatial_yield','fig05_interventions':'fig04_interventions',
 'fig06_recovery_exchange':'fig05_recovery_exchange','fig07_interactions':'fig06_interactions',
 'fig08_spatial_memory':'fig07_spatial_memory','fig13_operating_intervals':'fig08_pressure_intervals',
 'fig02_verification':'figS1_verification','fig09_controls':'figS2_controls',
 'fig10_mesh_verification':'figS3_mesh_thresholds','fig11_local_refinement':'figS4_local_refinement',
 'fig12_transient_verification':'figS5_transient_exchange'}
SOURCES={};NEW_DATA={};EXPORTS={};TEXT_EDITS={}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(rel):
    path=ROOT/rel;SOURCES[rel]=sha(path);return json.loads(path.read_text(encoding='utf8'))

WORDING={
 'Macro frozen':'Macro recovery off',
 'Pore frozen':'Pore recovery off',
 'Exchange frozen':'Gas exchange off',
 'Fine mesh.':'Reference mesh F.',
 'Coarse mesh':'Mesh C',
 'Fine mesh':'Mesh F',
 'M-controlled':'region M',
 'H-controlled':'region H',
 'First-plasticity pressure (MPa)':'Re-yield pressure (MPa)',
 'Recharging threshold (MPa)':'Re-yield pressure (MPa)',
 'Ranking-gap shift (MPa)':'Threshold-difference change (MPa)',
 'History-contrast sensitivity':'Sensitivity of the difference',
 'Absolute-pressure sensitivity':'Sensitivity of each threshold',
 'Sampled ranking differences':'Threshold differences',
 'Global field difference\nretained (%)':'Plastic-strain difference\nretained (%)',
 'Maximum paired-effect change (MPa)':'Change in freezing effect (MPa)',
 'Discrete sensitivity of interventions':'Sensitivity of freezing effects',
 'Separately prepared spectra':'Effect of the recovery spectrum',
 'Plastic memory persists across the waiting trajectory':'Plastic-strain difference during waiting',
 'Local A–B plastic-strain difference':'A–B plastic-strain difference',
 'Angular-column RMS strain (%)':'RMS strain difference (%)',
 'History-specific early effects':'Threshold changes after 40 s',
 'Freeze one waiting mechanism':'Suppressing one mechanism',
 'Bath / test':r'Remaining change $v_0$',
 'Transient − steady threshold (MPa)':'Transient − quasi-steady (MPa)',
 'Transient relative to steady':'Transient relative to quasi-steady',
 'Independent kernel verification':'Independent diffusion benchmark',
 'Matched transport-model shifts':'Change in re-yield pressure',
 'Change acquired in preparation':'Change in initial gas inventory',
 'Thresholds after local refinement':'Re-yield pressures',
 'Common pressure intervals':'Shared pressure intervals',
 'Shared finite-mesh intervals are reported separately from convergence of their endpoints.':'Each interval is shared by L1, L2, L3 and L1A10.',
 r'$R=8a$':r'$\rho=8a$',
 'Bath $\\pi_b(t)$':'Surrounding polymer $\\pi_b(t)$',
 'Stars: first-yield points':'Stars: points of renewed yield',
 'Markers are computed readouts;':'Markers are computed points;',
}

def wording(value):
    for a,b in WORDING.items():value=value.replace(a,b)
    return value

def export(fig,old_name):
    name=MAPPING.get(old_name,old_name);edits=[]
    # Tick label text is regenerated from its formatter during savefig.
    # Update that formatter when a categorical label needs a wording edit.
    fig.canvas.draw()
    for ax in fig.axes:
        for labels,positions,setter in [(ax.get_xticklabels(),ax.get_xticks(),ax.set_xticks),
                                        (ax.get_yticklabels(),ax.get_yticks(),ax.set_yticks)]:
            values=[x.get_text() for x in labels];newvalues=[wording(x) for x in values]
            if values!=newvalues:setter(positions,newvalues)
    for artist in fig.findobj(Text):
        old=artist.get_text();new=wording(old)
        if new!=old:artist.set_text(new);edits.append(dict(old=old,new=new))
    for ext in ('pdf','svg','png','tiff'):
        options={'dpi':600} if ext in ('png','tiff') else {}
        if ext=='tiff':options['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(OUT/f'{name}.{ext}',**options)
    fig.savefig(OUT/f'{name}_preview.png',dpi=170)
    EXPORTS[name]={'original_stem':old_name,'height_mm':float(fig.get_figheight()*25.4),
        'width_mm':float(fig.get_figwidth()*25.4),
        'files':{e:sha(OUT/f'{name}.{e}') for e in ('pdf','svg','png','tiff')},
        'preview_sha256':sha(OUT/f'{name}_preview.png')}
    TEXT_EDITS[name]=edits
    plt.close(fig)

def thresholds():
    """Reference curves and independently checked stages; no fitted crossing times."""
    d=read('screening/local_refinement_summary_round24.json')
    assert d['status']=='complete' and d['audit_status']=='passed'
    keys=['R0','L1','L2','L3','L1A10'];times=[0.,122.71562236407772,7200.]
    selected={k:[next(r for r in d['meshes'][k]['rows'] if abs(r['time_s']-t)<1e-6) for t in times] for k in keys}
    for t in times:
        check=next(r for r in d['joint_stage_assessment'] if abs(r['time_s']-t)<1e-6)
        assert check['common_sign_and_final_radial_and_angular_margins_pass']
        assert check['distinguishability_delta1_on_all_meshes']
    fig=plt.figure(figsize=(180*general.MM,162*general.MM))
    gs=fig.add_gridspec(2,2,left=.105,right=.98,bottom=.15,top=.935,wspace=.40,hspace=.69,height_ratios=[1,.94])
    a=fig.add_subplot(gs[0,0]);b=fig.add_subplot(gs[0,1]);c=fig.add_subplot(gs[1,:])
    for key,col,lab in [('A',general.BLUE,'History A'),('B',general.ORANGE,'History B')]:
        a.plot([r['time_s'] for r in general.fine],[r[key] for r in general.fine],'-o',color=col,label=lab)
    general.wait_axis(a);a.set_ylim(7,34);a.set_ylabel('Re-yield pressure (MPa)')
    a.legend(loc='lower left',ncol=1,fontsize=general.FS_LEGEND)
    general.panel(a,'a','Reference pressures')
    b.axhspan(-1,1,color='#E5E9ED',zorder=-3);b.axhline(0,color=general.GREY,lw=.7)
    b.plot([r['time_s'] for r in general.fine],[r['gap'] for r in general.fine],'-o',color=general.INK)
    general.wait_axis(b);b.set_ylim(-4.5,13)
    b.set_ylabel(r'$P_A^*-P_B^*$ (MPa)')
    general.panel(b,'b','Reference threshold difference')
    for t,offset in [(0.,(8,0)),(300.,(0,-14)),(7200.,(-18,10))]:
        r=next(r for r in general.fine if r['time_s']==t)
        b.annotate(f"{r['gap']:+.2f}",(t,r['gap']),xytext=offset,textcoords='offset points',fontsize=general.FS_ANNOTATION)
    c.axhspan(-1,1,color='#E5E9ED',zorder=-3);c.axhline(0,color=general.GREY,lw=.7)
    offsets=np.linspace(-.12,.12,len(keys));anchor=np.arange(3)
    for k,off in zip(keys,offsets):
        col,mark,ls=local.STYLES[k]
        c.plot(anchor+off,[r['A']-r['B'] for r in selected[k]],marker=mark,ls='none',color=col,
               markerfacecolor='white' if 'A10' in k else col,ms=5,label=k)
    c.set_xticks(anchor,['0','122.716 s','2 h']);c.set_xlim(-.5,2.5);c.set_ylim(-2.5,14.7)
    c.set_xlabel('Waiting time');c.set_ylabel(r'$P_A^*-P_B^*$ (MPa)');general.grid(c)
    general.panel(c,'c','Repeated reversal across five pore meshes')
    for i,label in enumerate(['A has the higher threshold','B has the higher threshold','A has the higher threshold']):
        c.text(i,13.4,label,ha='center',va='center',fontsize=general.FS_ANNOTATION)
    c.legend(loc='center',bbox_to_anchor=(.5,-.37),ncol=5,fontsize=general.FS_LEGEND,columnspacing=1.7,handlelength=1)
    fig.text(.5,.018,'(a,b) Reference mesh F.  (c) Actual readouts on R0 and the four refined meshes.',ha='center',fontsize=general.FS_NOTE,color=general.GREY)
    NEW_DATA['fig02']={'reference_mesh':'F','reference_rows':general.fine,'comparison_meshes':keys,
         'observed_times_s':times,'mesh_rows':selected,'shaded_pressure_difference_band_MPa':[-1.,1.],
         'curve_semantics':'Panels a,b connect reference-mesh samples. Panel c is a discrete comparison; no crossing time is interpolated.'}
    export(fig,'fig03_thresholds')

def main():
    for module in (general,local,transport):module.export=export
    spatial.save=export;spatial.DATA=SPATIAL
    general.figure1();thresholds()
    spatial_data={'fig03':spatial.spatial_yield(),'fig07':spatial.spatial_memory()}
    for fn in (general.figure5,general.figure6,general.figure7,local.figure13,
               general.figure2,general.figure9,local.figure10,local.figure11,transport.figure12):fn()
    for m in (general,local,transport,spatial):
        source=getattr(m,'SOURCES',getattr(m,'SRC',{}));SOURCES.update(source)
        file=Path(m.__file__);SOURCES[file.relative_to(ROOT).as_posix()]=sha(file)
    SOURCES[Path(__file__).relative_to(ROOT).as_posix()]=sha(__file__)
    for rel in ('mechanics/pore_octant_geometry_round17.py','mechanics/dp_plasticity_round17.py'):
        SOURCES[rel]=sha(ROOT/rel)
    generalmap={'fig01':'fig01','fig05':'fig04','fig06_A':'fig05_A','fig06_B':'fig05_B','fig07':'fig06','fig02':'figS1','fig09':'figS2'}
    data={generalmap[k]:v for k,v in general.DATA.items() if k in generalmap};data.update(NEW_DATA);data.update(spatial_data)
    data.update({'fig08':local.DATA['fig13'],'figS3':local.DATA['fig10'],'figS4':local.DATA['fig11'],'figS5':transport.DATA['fig12']})
    for stem in ('yield_envelope_40s','plastic_difference_angular_rms'):
        p=SPATIAL/f'{stem}.csv'
        with p.open(encoding='utf8',newline='') as f:data[stem]=list(csv.DictReader(f))
    record={'status':'rendered_pending_visual_review','new_mechanics_solves':False,'mapping_old_to_final':MAPPING,
        'source_sha256':SOURCES,'data':data,'export':EXPORTS,'wording_changes':TEXT_EDITS,
        'statistics':'Deterministic simulations. Markers are computed values; ranges across meshes are discretization comparisons, not statistical confidence intervals.',
        'typography':{'text':'Times New Roman','math':'STIX','width_mm':180,'raster_dpi':600,
            'axes_labels_pt':10.5,'ticks_legends_annotations_pt':9.5,'panel_marks_pt':12,'supporting_notes_pt':9}}
    (OUT/'final_figure_source_data_round25.json').write_text(json.dumps(record,indent=2),encoding='utf8')
    (OUT/'FIGURE_MAPPING.json').write_text(json.dumps(MAPPING,indent=2),encoding='utf8')
    print(json.dumps({'rendered':len(EXPORTS),'main_figures':8,'supplementary_figures':5,'new_mechanics_solves':False}))

def refresh_supplementary_refinement():
    """Refresh one wording-only export, retaining every other final master."""
    record_path=OUT/'final_figure_source_data_round25.json'
    record=json.loads(record_path.read_text(encoding='utf8'))
    current_script=Path(__file__).relative_to(ROOT).as_posix()
    for rel,digest in record['source_sha256'].items():
        if rel!=current_script:
            assert sha(ROOT/rel)==digest, f'Archived input changed: {rel}'
    local.export=export
    local.figure11()
    assert local.DATA['fig11']==record['data']['figS4'], 'Plotted numerical data changed'
    assert set(EXPORTS)=={'figS4_local_refinement'}
    record['export'].update(EXPORTS)
    record['wording_changes'].update(TEXT_EDITS)
    record['source_sha256'][current_script]=sha(__file__)
    record['status']='rendered_pending_visual_review'
    record.pop('visual_review_file',None)
    record_path.write_text(json.dumps(record,indent=2),encoding='utf8')
    print(json.dumps({'rendered':1,'figure':'figS4_local_refinement','numerical_data_changed':False,
                      'new_mechanics_solves':False}))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only',choices=['figS4_local_refinement'])
    args=parser.parse_args()
    if args.only:refresh_supplementary_refinement()
    else:main()
