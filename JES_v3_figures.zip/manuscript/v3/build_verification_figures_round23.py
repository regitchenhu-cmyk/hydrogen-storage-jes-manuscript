"""Publication verification figures from completed Round23 numerical results."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from build_publication_figures import (MM,BLUE,ORANGE,INK,GREY,GREEN,FS_LABEL,
    FS_TICK,FS_LEGEND,FS_ANNOTATION,FS_NOTE,panel,grid,export)

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'manuscript/figures_v3'
SOURCES={};DATA={}

def read(rel):
    p=ROOT/rel;SOURCES[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text(encoding='utf-8'))

def lookup(rows,t):
    return next(r for r in rows if abs(r['time_s']-t)<.01)

def thresholds(mode,mesh,refine):
    d=read(f'mechanics/transient_{mode}_{mesh}_dt{refine}_round23.json')
    if d['status']!='complete':raise RuntimeError('Unfinished transport computation')
    return {(r['wait_seconds'],r['pulse_MPa']):r['first_reyield']['pressure_MPa']
            for r in d['results']}

def _historical_three_mesh_thresholds_round23():
    d=read('screening/mesh_verification_summary_round23.json')
    if d['status']!='complete':raise RuntimeError('Unfinished mesh computation')
    meshes=d['meshes'];keys=['coarse','fine','finer'];x=np.arange(3)
    times=[0.,60.,300.,1800.,7200.,146118.72146]
    titles=['Immediate recharge','After 1 min','After 5 min','After 30 min','After 2 h','After 40.59 h']
    fig,axs=plt.subplots(3,2,figsize=(180*MM,194*MM))
    fig.subplots_adjust(left=.12,right=.98,bottom=.10,top=.94,wspace=.36,hspace=.77)
    plotted=[]
    for ax,t,title,letter in zip(axs.flat,times,titles,'abcdef'):
        rr=[lookup(meshes[k]['rows'],t) for k in keys]
        for key,c in [('A',BLUE),('B',ORANGE)]:
            yy=[r[key] for r in rr]
            ax.plot(x,yy,'-o',color=c,label='History '+key,markersize=4)
        ax.set_xticks(x,[str(meshes[k]['elements']) for k in keys])
        ax.set_xlim(-.15,2.15);ax.set_xlabel('Elements in pore mesh')
        ax.set_ylabel('First-plasticity pressure (MPa)')
        ax.margins(y=.18);grid(ax);panel(ax,letter,title)
        plotted.append({'time_s':t,'rows':rr})
    axs[0,0].legend(loc='best',fontsize=FS_LEGEND)
    fig.text(.5,.025,'Each mesh is prepared from ambient equilibrium; lines connect computed thresholds.',
             ha='center',fontsize=FS_NOTE,color=GREY)
    DATA['fig10']={'mesh_keys':keys,'elements':[meshes[k]['elements'] for k in keys],'samples':plotted}
    export(fig,'fig10_mesh_verification')

def figure12():
    independent=read('screening/transient_kernel_independent_reference_round23.json')
    coarse={}
    for refine in [1,2]:
        coarse[refine]={mode:thresholds(mode,'coarse',refine) for mode in ['quasisteady','transient']}
    fine=thresholds('transient','fine',1)
    mesh=read('screening/mesh_verification_summary_round23.json')
    fine_qs={(r['time_s'],amp):r[key] for r in mesh['meshes']['fine']['rows']
             for amp,key in [(-10,'A'),(-40,'B')]}
    fig,axs=plt.subplots(2,2,figsize=(180*MM,156*MM))
    fig.subplots_adjust(left=.12,right=.98,bottom=.12,top=.92,wspace=.40,hspace=.67)
    a,b,c,d=axs.flat
    rr=independent['coupled_fixed_volume_convergence']
    n=np.array([r['steps'] for r in rr]);err=np.array([r['absolute_error_MPa'] for r in rr])
    a.loglog(n,err,'o-',color=INK,label='Against analytic solution')
    a.loglog(n,err[0]*n[0]/n,'--',color=GREY,label=r'$O(\Delta t)$')
    a.set_xticks(n,[str(x) for x in n]);a.minorticks_off()
    a.set_xlabel('Time increments');a.set_ylabel('Pressure error (MPa)')
    a.legend(loc='upper right',fontsize=FS_LEGEND);grid(a);panel(a,'a','Independent kernel verification')
    times=[0.,40.,300.,1800.,7200.];labels=['0','40 s','5 min','30 min','2 h'];x=np.arange(len(times))
    shifts={}
    for amp,col,hist in [(-10,BLUE,'A'),(-40,ORANGE,'B')]:
        for refine,ls,marker in [(1,'--','o'),(2,'-','s')]:
            yy=[coarse[refine]['transient'][t,amp]-coarse[refine]['quasisteady'][t,amp] for t in times]
            b.plot(x,yy,ls,marker=marker,color=col,label=f'{hist}, '+('base step' if refine==1 else 'half step'))
            shifts[f'{hist}_dt{refine}']=yy
    b.axhline(0,color=GREY,lw=.7);b.set_xticks(x,labels);b.set_xlabel('Waiting time')
    b.set_ylabel('Transient − steady threshold (MPa)');grid(b);panel(b,'b','Matched transport-model shifts')
    b.set_ylim(-.075,.075)
    b.legend(loc='upper left',ncol=2,fontsize=FS_LEGEND,columnspacing=.9,handlelength=1.7)
    prepared={}
    for refine in [1,2]:
        pp={}
        for mode in ['quasisteady','transient']:
            src=read(f'mechanics/transient_{mode}_coarse_dt{refine}_preparation_round23.json')
            pp[mode]={r['amplitude']:r['N'] for r in src['paths']}
        prepared[refine]=[100*(pp['transient'][amp]/pp['quasisteady'][amp]-1) for amp in [10,40]]
    for dx,refine,col,label in [(-.17,1,GREY,'Base step'),(.17,2,GREEN,'Half step')]:
        c.bar(np.arange(2)+dx,prepared[refine],.30,color=col,label=label,zorder=3)
    c.set_xticks([0,1],['History A','History B']);c.axhline(0,color=GREY,lw=.7)
    c.set_ylabel('Prepared inventory change (%)');c.set_xlabel('Transient relative to steady')
    c.legend(loc='best',fontsize=FS_LEGEND);grid(c);panel(c,'c','Change acquired in preparation')
    tf=[0.,40.,300.,1800.,7200.];lf=['0','40 s','5 min','30 min','2 h'];xf=np.arange(len(tf));fs={}
    for amp,col,hist in [(-10,BLUE,'A'),(-40,ORANGE,'B')]:
        yy=[fine[t,amp]-next(v for (tt,aa),v in fine_qs.items() if aa==amp and abs(tt-t)<.01) for t in tf]
        d.plot(xf,yy,'-o',color=col,label='History '+hist);fs[hist]=yy
    d.axhline(0,color=GREY,lw=.7);d.set_xticks(xf,lf);d.set_xlabel('Waiting time')
    d.set_ylabel('Transient − steady threshold (MPa)');d.legend(loc='best',fontsize=FS_LEGEND)
    grid(d);panel(d,'d','Transport check on 288 elements')
    fig.text(.5,.022,'Full preparation is repeated for each transport model and time resolution.',
             ha='center',fontsize=FS_NOTE,color=GREY)
    DATA['fig12']={'kernel_convergence':rr,'times_s':times,'coarse_model_shifts_MPa':shifts,
                   'prepared_inventory_changes_percent':prepared,'fine_times_s':tf,'fine_model_shifts_MPa':fs}
    export(fig,'fig12_transient_verification')

if __name__=='__main__':
    # Round24 local-refinement builder now owns Figures10 and11.
    # This completed transport comparison retains its data and becomes Figure12.
    figure12()
    result={'source_sha256':SOURCES,'data':DATA,'export':{'width_mm':180,'raster_dpi':600,
        'text':'Times New Roman','math':'STIX','labels_pt':FS_LABEL,'ticks_legends_pt':FS_TICK},
        'scope':'Completed deterministic numerical verification; no statistical error bars.'}
    (OUT/'verification_source_data_round23.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print('Exported Figure12 from the unchanged completed Round23 transport runs.')
