"""Spatial evidence from saved quadrature states; no mechanical evolution solves.

Python-only publication rendering at the final 180 mm figure width. Angular
cells display discrete Gauss-point columns, not interpolated field values.
"""
from pathlib import Path
import sys, json, hashlib, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'manuscript'/'figures_v3'
DATA=ROOT/'manuscript'/'v3'/'spatial_data'
OUT.mkdir(parents=True,exist_ok=True);DATA.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'mechanics'))
from pore_octant_geometry_round17 import PoreOctantMesh
from dp_plasticity_round17 import elastic_constants

SOURCES={}; CHECKS=[]
BLUE,ORANGE,GRAY='#0072B2','#D55E00','#7E8792'
FS_LABEL=10.5
FS_TICK=9.5
FS_LEGEND=9.5
FS_PANEL=12
FS_TITLE=10.5
FS_ANNOTATION=9.5
FS_FOOTER=9
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman'],
 'font.size':FS_ANNOTATION,'axes.labelsize':FS_LABEL,'axes.titlesize':FS_TITLE,
 'axes.titleweight':'normal','xtick.labelsize':FS_TICK,
 'ytick.labelsize':FS_TICK,'legend.fontsize':FS_LEGEND,'axes.linewidth':.7,'xtick.major.width':.7,
 'ytick.major.width':.7,'axes.spines.top':False,'axes.spines.right':False,
 'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white',
 'mathtext.fontset':'stix','mathtext.fallback':'stix'})

def register(rel):
    p=ROOT/rel;SOURCES[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return p

def read(rel):
    return json.loads(register(rel).read_text(encoding='utf-8'))

def state(rel):
    with np.load(register(rel)) as d:return {k:d[k].copy() for k in d.files}

def check(label,passed,**extra):
    CHECKS.append({'check':label,'passed':bool(passed),**extra})
    if not passed:raise AssertionError(label)

MESH=PoreOctantMesh(nr=8,nt=6,np_=6)
C=elastic_constants(1.,.3)[2]
E_MPA=2871.
RADIUS=np.linalg.norm(MESH.xyz,axis=-1)
THETA=np.degrees(np.arccos(np.clip(MESH.xyz[...,2]/RADIUS,-1,1)))
PHI=np.degrees(np.arctan2(MESH.xyz[...,1],MESH.xyz[...,0]))
# Elements are ordered radial, polar, azimuthal; quadrature follows the same
# three-coordinate ordering. This groups actual points along angular columns.
COL=np.empty((288,27,2),int)
for e in range(288):
    ri,tj,pk=np.unravel_index(e,(8,6,6))
    for q in range(27):
        qr,qt,qp=np.unravel_index(q,(3,3,3))
        COL[e,q]=[tj*3+qt,pk*3+qp]
POL=np.array([np.median(THETA[COL[...,0]==j]) for j in range(18)])
AZ=np.array([np.median(PHI[COL[...,1]==j]) for j in range(18)])
EDGES=lambda x: np.r_[0.,.5*(x[:-1]+x[1:]),90.]
POL_EDGES,AZ_EDGES=EDGES(POL),EDGES(AZ)

def column_values(values,mode='max'):
    out=np.zeros((18,18));counts=np.zeros((18,18),int)
    for j in range(18):
        for k in range(18):
            mask=(COL[...,0]==j)&(COL[...,1]==k)&(RADIUS<2.)
            counts[j,k]=mask.sum()
            if mode=='max':out[j,k]=values[mask].max()
            elif mode=='weighted_rms':
                out[j,k]=np.sqrt(np.sum(MESH.weights[mask]*values[mask]**2)/MESH.weights[mask].sum())
            else:raise ValueError(mode)
    check('All angular columns contain near-pore samples',counts.min()>0,
          min_count=int(counts.min()),max_count=int(counts.max()))
    return out

def yield_field(s):
    meta=json.loads(str(s['metadata']))
    fractions=np.array([x['fraction'] for x in meta['branches']])
    e=MESH.strain(s['u'])-s['epsp']
    stress=E_MPA*np.einsum('ij,eqj->eqi',C,e-np.einsum('b,beqi->eqi',fractions,s['z']))
    tr=stress[...,:3].sum(-1);dev=stress.copy();dev[...,:3]-=tr[...,None]/3
    par=meta['parameters'];alpha=(par['ratio']-1)/(par['ratio']+1)
    f=np.sqrt(1.5*np.sum(dev*dev,-1))+alpha*tr-par['T']*(1+alpha)-par['hardening']*E_MPA*s['kappa']
    return f,stress

def panel_title(ax,letter,title,pad=24,title_x=.1):
    ax.set_title(title,loc='left',x=title_x,fontweight='normal',fontsize=FS_TITLE,pad=pad)
    ax.annotate(f'({letter})',xy=(0,1),xycoords='axes fraction',
                xytext=(0,pad),textcoords='offset points',ha='left',va='baseline',
                fontsize=FS_PANEL,fontweight='bold',annotation_clip=False)

def map_axes(ax,letter,title):
    ax.set_xlim(0,90);ax.set_ylim(90,0)
    ax.set_xticks([0,30,60,90]);ax.set_yticks([0,30,60,90])
    ax.set_xlabel(r'Azimuth $\phi_p$ (°)',labelpad=3)
    ax.set_ylabel(r'Polar angle $\theta_p$ (°)',labelpad=3)
    ax.set_aspect('equal')
    panel_title(ax,letter,title)
    ax.tick_params(length=3,pad=2)

def save(fig,name):
    for ext in ['pdf','svg','png','tiff']:
        kw={'dpi':600}
        if ext=='tiff':kw['pil_kwargs']={'compression':'tiff_lzw'}
        fig.savefig(OUT/f'{name}.{ext}',**kw)
    fig.savefig(OUT/f'{name}_preview.png',dpi=180)
    plt.close(fig)

def spatial_yield():
    roots=read('screening/viscoelastic_hotspot_audit_fine40_round21.json')['results']
    details={int(abs(r['pulse_MPa'])):r['onset'] for r in roots}
    sets=[]
    for amp in [10,40]:
        s=state(f'mechanics/mechanism_none_fine_pulse{amp}_wait40_normal_root_round22_pore.npz')
        f,stress=yield_field(s);ix=np.unravel_index(np.argmax(f),f.shape)
        expected=details[amp]
        check(f'History {amp}: exact critical element and quadrature',
              list(ix)==[expected['critical_element'],expected['critical_quadrature']],indices=list(map(int,ix)))
        check(f'History {amp}: root yield residual',abs(f[ix])<2e-8,root_residual_MPa=float(f[ix]))
        check(f'History {amp}: critical stress audit',np.max(np.abs(stress[ix]-expected['critical_stress_mandel_MPa']))<1e-7,
              max_difference_MPa=float(np.max(np.abs(stress[ix]-expected['critical_stress_mandel_MPa']))))
        vals=column_values(f)
        sets.append({'amplitude_MPa':amp,'pressure_MPa':float(s['vessel_MPa']),
            'f':vals,'critical_phi':float(PHI[ix]),'critical_theta':float(THETA[ix]),
            'critical_radius_over_a':float(RADIUS[ix]),'point':list(map(int,ix))})
    with (DATA/'yield_envelope_40s.csv').open('w',newline='',encoding='utf-8') as h:
        w=csv.writer(h);w.writerow(['polar_angle_deg','azimuth_angle_deg','A_radial_max_f_MPa','B_radial_max_f_MPa'])
        for j in range(18):
            for k in range(18):w.writerow([POL[j],AZ[k],sets[0]['f'][j,k],sets[1]['f'][j,k]])
    vmin=5*np.floor(min(s['f'].min() for s in sets)/5)
    fig=plt.figure(figsize=(180/25.4,91/25.4))
    axes=[fig.add_axes([.09,.21,.32,.633]),fig.add_axes([.52,.21,.32,.633])]
    for i,(s,ax,history,region,col) in enumerate(zip(sets,axes,['A','B'],['M','H'],[BLUE,ORANGE])):
        im=ax.pcolormesh(AZ_EDGES,POL_EDGES,s['f'],vmin=vmin,vmax=0,cmap='cividis',shading='flat',rasterized=False)
        map_axes(ax,chr(97+i),f'History {history}: {region}-controlled')
        ax.text(0,1.035,rf'$P^*={s["pressure_MPa"]:.3f}$ MPa',transform=ax.transAxes,color=col,fontsize=FS_ANNOTATION)
        for x,y,width,height,label in [(0,0,90,15,'H'),(30,75,30,15,'M'),(75,75,15,15,'Z')]:
            ax.add_patch(Rectangle((x,y),width,height,fill=False,edgecolor='white',lw=.85,ls=(0,(3,2))))
            ax.text(x+width*.78,y+height*.67,label,ha='center',va='center',fontsize=FS_ANNOTATION,fontweight='bold',
                    bbox={'boxstyle':'round,pad=.13','facecolor':'white','edgecolor':'none','alpha':.93})
        ax.scatter(s['critical_phi'],s['critical_theta'],marker='*',s=90,c=col,edgecolors='white',linewidths=.85,zorder=6,clip_on=False)
    cax=fig.add_axes([.885,.275,.018,.50]);cb=fig.colorbar(im,cax=cax)
    cb.set_label(r'Radial maximum of $f$ (MPa)',fontsize=FS_LABEL,labelpad=5)
    cb.ax.tick_params(labelsize=FS_TICK,length=2.5,pad=2)
    fig.text(.09,.045,r'40 s wait  |  $\rho<2a$  |  Stars: first-yield points  |  Discrete angular columns',fontsize=FS_FOOTER,color='#3E454B')
    save(fig,'fig04_spatial_yield')
    return {'maps':[{k:v for k,v in s.items() if k!='f'} for s in sets],
        'range_MPa':[float(vmin),0.], 'csv':'spatial_data/yield_envelope_40s.csv',
        'caption':'At each history\'s own exact first-yield pressure after 40 s of waiting, color gives the maximum yield function over the saved quadrature points with rho < 2a in each angular column. A and B share a color scale. Stars mark the actual critical quadrature point, and dashed boxes identify H, M and Z. Angular tiles display discrete column values without interpolation. The angular-cell edges are midpoints between adjacent Gauss-point columns, extended to 0 and 90 degrees.'}

def spatial_memory():
    maps=[];global_rms=[]
    for ts in ['0','146119']:
        a=state(f'mechanics/viscoelastic_main_fine_pulse10_wait{ts}_round21_pore.npz')
        b=state(f'mechanics/viscoelastic_main_fine_pulse40_wait{ts}_round21_pore.npz')
        norm=np.linalg.norm(a['epsp']-b['epsp'],axis=-1)
        rms=float(np.sqrt(np.sum(MESH.weights*norm**2)/MESH.weights.sum()))
        maps.append(column_values(norm,'weighted_rms')*100);global_rms.append(rms)
    summary=read('mechanics/viscoelastic_summary_round21.json')
    expected=summary['main_fine_plastic_field_difference_remaining_fraction']
    check('Whole-volume retention independently reproduced',abs(global_rms[1]/global_rms[0]-expected)<1e-13,
          ratio=global_rms[1]/global_rms[0],initial_RMS=global_rms[0],final_RMS=global_rms[1])
    with (DATA/'plastic_difference_angular_rms.csv').open('w',newline='',encoding='utf-8') as h:
        w=csv.writer(h);w.writerow(['polar_angle_deg','azimuth_angle_deg','initial_angular_column_RMS_percent','final_angular_column_RMS_percent'])
        for j in range(18):
            for k in range(18):w.writerow([POL[j],AZ[k],maps[0][j,k],maps[1][j,k]])
    vmax=np.ceil(max(v.max() for v in maps)*10)/10
    fig=plt.figure(figsize=(180/25.4,147/25.4))
    axes=[fig.add_axes([.09,.50,.32,.40]),fig.add_axes([.52,.50,.32,.40])]
    for i,(v,ax,label) in enumerate(zip(maps,axes,['After preparation','After 40.59 h'])):
        im=ax.pcolormesh(AZ_EDGES,POL_EDGES,v,vmin=0,vmax=vmax,cmap='magma_r',shading='flat',rasterized=False)
        map_axes(ax,chr(97+i),label)
        ax.text(0,1.035,r'Local A–B plastic-strain difference',transform=ax.transAxes,fontsize=FS_ANNOTATION)
    cax=fig.add_axes([.885,.55,.018,.30]);cb=fig.colorbar(im,cax=cax)
    cb.set_label('Angular-column RMS strain (%)',fontsize=FS_LABEL,labelpad=5)
    cb.ax.tick_params(labelsize=FS_TICK,length=2.5,pad=2)
    ax=fig.add_axes([.14,.11,.70,.25])
    for key,col,ls,label in [('main_coarse',GRAY,':','Coarse mesh'),('main_fine',BLUE,'-','Fine mesh')]:
        vals=np.array(summary[key+'_plastic_field_difference_RMS']);t=np.array([r['time_s'] for r in summary['tables'][key]])
        ax.plot(t,100*vals/vals[0],ls+'o',ms=3,lw=1.2,color=col,label=label)
    ax.set_xscale('symlog',linthresh=1);ax.set_xlim(-.05,2e5);ax.set_ylim(94.5,100.6)
    ax.set_xticks([0,10,60,300,1800,7200,summary['horizon_seconds']],['0','10 s','1 min','5 min','30 min','2 h','40.59 h'])
    ax.set_yticks([95,97.5,100]);ax.set_ylabel('Global field difference\nretained (%)',labelpad=4)
    ax.set_xlabel('Waiting time',labelpad=4)
    panel_title(ax,'c','Plastic memory persists across the waiting trajectory',pad=12,title_x=.045)
    ax.axhline(100,color='#B2B7BD',lw=.6,ls=(0,(3,3)));ax.grid(axis='y',alpha=.14,lw=.5)
    ax.legend(loc='lower left',ncol=2,bbox_to_anchor=(0,.03),frameon=False)
    ax.annotate(f'{100*expected:.2f}%',xy=(summary['horizon_seconds'],100*expected),xytext=(25000,97.25),
                color=BLUE,fontsize=FS_ANNOTATION,fontweight='bold',arrowprops={'arrowstyle':'-','lw':.8,'color':BLUE})
    save(fig,'fig08_spatial_memory')
    return {'angular_map_range_percent':[0,float(vmax)],'global_RMS':global_rms,
            'global_retained_fraction':global_rms[1]/global_rms[0],
            'csv':'spatial_data/plastic_difference_angular_rms.csv',
            'caption':'Panels a and b show the reference-volume-weighted root-mean-square of the A–B plastic-strain tensor difference along each angular column restricted to rho < 2a. Values are strains expressed in percent and share one color scale. Tiles represent discrete Gauss-point columns without smoothing. Panel c separately shows the full-solid-volume RMS difference normalized by its own preparation value for each mesh. The final fine-mesh value is 95.94%; this percentage is a whole-volume metric, not a per-pixel normalization.'}

if __name__=='__main__':
    register('mechanics/pore_octant_geometry_round17.py');register('mechanics/dp_plasticity_round17.py')
    register('mechanics/plastic_pore_round17.py')  # E=2.871 GPa and nu=0.3 model defaults
    out={'figure_contract':{'backend':'Python/Matplotlib','width_mm':180,
         'fonts':{'text':'Times New Roman','math':'STIX','axis_labels_pt':FS_LABEL,
                  'ticks_pt':FS_TICK,'legends_pt':FS_LEGEND,'panel_labels_pt':FS_PANEL,
                  'titles_pt':FS_TITLE,'annotations_pt':FS_ANNOTATION,'footers_pt':FS_FOOTER},
         'panel_label_style':'parenthesized lower-case letters, bold, separate from normal-weight titles',
         'figure_heights_mm':{'figure4':91,'figure8':147},
         'formats':['PDF','editable SVG','600 dpi PNG','600 dpi LZW TIFF'],
         'figure4_claim':'Two histories yield at different spatial branches after the same waiting time.',
         'figure8_claim':'Spatial plastic-state differences persist even as scalar threshold rankings change.'},
         'local_coordinates':'polar theta_p from circumferential axis; azimuth phi_p from radial towards axial axis',
         'material_constants':{'instantaneous_Youngs_modulus_MPa':E_MPA,'Poisson_ratio':0.3},
         'figure4':spatial_yield(),'figure8':spatial_memory(),
         'new_equilibrium_solves':False,'checks':CHECKS,'source_sha256':SOURCES}
    (OUT/'spatial_figure_provenance.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'figures':2,'checks':len(CHECKS),'all_passed':all(x['passed'] for x in CHECKS),
                      'global_retained_fraction':out['figure8']['global_retained_fraction']},indent=2))
