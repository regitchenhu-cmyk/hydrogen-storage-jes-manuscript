"""Check final figure exports and compare every reused plotted array to its archive."""
from pathlib import Path
import hashlib,json,math
import fitz
from PIL import Image

ROOT=Path(__file__).resolve().parents[2];F=ROOT/'manuscript/figures_final'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text(encoding='utf8'))
d=load(F/'final_figure_source_data_round25.json');checks=[]
def check(n,v):
    checks.append(dict(name=n,passed=bool(v)))
    if not v:print('FAIL '+n)
old=ROOT/'manuscript/figures_v3'
gd=load(old/'publication_source_data.json')['data']
ld=load(old/'local_refinement_source_data_round24.json')['data']
td=load(old/'verification_source_data_round23.json')['data']
sd=load(old/'spatial_figure_provenance.json')
for new,original in {'fig01':'fig01','fig04':'fig05','fig05_A':'fig06_A','fig05_B':'fig06_B','fig06':'fig07','figS1':'fig02','figS2':'fig09'}.items():
    check(new+' arrays equal preserved source',d['data'][new]==gd[original])
for new,original in {'fig08':'fig13','figS3':'fig10','figS4':'fig11'}.items():
    check(new+' arrays equal preserved source',d['data'][new]==ld[original])
check('figS5 arrays equal preserved transport',d['data']['figS5']==td['fig12'])
for new,original in [('fig03','figure4'),('fig07','figure8')]:
    check(new+' field metadata equal preserved source',d['data'][new]==sd[original])
for filename in ['yield_envelope_40s.csv','plastic_difference_angular_rms.csv']:
    check(filename+' exact preserved plotted spatial grid',sha(F/'spatial_data'/filename)==sha(ROOT/'manuscript/v3/spatial_data'/filename))
ref=d['data']['fig02'];local=load(ROOT/'screening/local_refinement_summary_round24.json')
check('Fig2 reference curve matches preserved F record',ref['reference_rows']==gd['fig03']['fine'])
for k,rows in ref['mesh_rows'].items():
    check('Fig2 all three '+k+' times',len(rows)==3)
    for r,t in zip(rows,ref['observed_times_s']):
        actual=next(x for x in local['meshes'][k]['rows'] if abs(x['time_s']-t)<1e-6)
        check('Fig2 '+k+'/'+str(t)+' original full row',actual==r)
        check('Fig2 '+k+'/'+str(t)+' exceeds 1 MPa',abs(r['A']-r['B'])>1)
        check('Fig2 '+k+'/'+str(t)+' direction',(r['A']>r['B'])==(t!=ref['observed_times_s'][1]))
for t in ref['observed_times_s']:
    j=next(x for x in local['joint_stage_assessment'] if abs(x['time_s']-t)<1e-6)
    check('Fig2 '+str(t)+' passes declared comparison',j['common_sign_and_final_radial_and_angular_margins_pass'])
for rel,digest in d['source_sha256'].items():check('Source unchanged: '+rel,(ROOT/rel).is_file() and sha(ROOT/rel)==digest)
records=[]
for stem,info in d['export'].items():
    doc=fitz.open(F/f'{stem}.pdf');p=doc[0]
    fonts=[dict(name=x[3],embedded=bool(doc.extract_font(x[0])[3])) for x in p.get_fonts(full=True)]
    png=Image.open(F/f'{stem}.png');tiff=Image.open(F/f'{stem}.tiff')
    svg=(F/f'{stem}.svg').read_text(encoding='utf8')
    check(stem+' PDF width 180 mm',abs(p.rect.width*25.4/72-180)<.01)
    check(stem+' fonts embedded',bool(fonts) and all(f['embedded'] for f in fonts))
    check(stem+' vector text', '<text' in svg)
    check(stem+' matched PNG/TIFF pixels',png.size==tiff.size)
    check(stem+' PNG 600 dpi',all(abs(v-600)<.1 for v in png.info['dpi']))
    check(stem+' TIFF 600 dpi',all(abs(v-600)<.1 for v in tiff.info['dpi']))
    check(stem+' TIFF LZW',tiff.tag_v2[259]==5)
    for e,h in info['files'].items():check(stem+' '+e+' current export',sha(F/f'{stem}.{e}')==h)
    check(stem+' preview unchanged',sha(F/f'{stem}_preview.png')==info['preview_sha256'])
    records.append(dict(stem=stem,fonts=fonts,png_pixels=png.size,pdf_sha256=sha(F/f'{stem}.pdf'),preview_sha256=info['preview_sha256']))
report=dict(status='passed' if all(x['passed'] for x in checks) else 'failed',checks=checks,
    check_count=len(checks),figures=records,new_mechanics_solves=False,source_extract_sha256=sha(F/'final_figure_source_data_round25.json'))
(F/'FIGURE_EXPORT_AUDIT_ROUND25.json').write_text(json.dumps(report,indent=2),encoding='utf8')
print(json.dumps(dict(status=report['status'],checks=report['check_count'],failures=[r['name'] for r in checks if not r['passed']])))
if report['status']!='passed':raise SystemExit(1)
