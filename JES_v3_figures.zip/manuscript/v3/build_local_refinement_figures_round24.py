"""Local pore-wall verification plots from completed, independently extracted runs.

No equilibrium solve or interpolation of states occurs here. Lines join actual
readouts and have no status as an interpolation of reversal times.
"""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from build_publication_figures import (MM,BLUE,ORANGE,INK,GREY,GREEN,PURPLE,
    FS_NOTE,FS_LEGEND,FS_ANNOTATION,panel,grid,export)

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'manuscript/figures_v3'
SOURCES={};DATA={}
STYLES={'R0':(GREY,'o','--'),'L1':(BLUE,'s','-'),
        'L2':(ORANGE,'^','-'),'L3':(GREEN,'v','-'),
        'L1A10':(PURPLE,'D',':'),'L2A10':('#9D6E24','X','-.')}

def read(rel):
    p=ROOT/rel;SOURCES[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
    return json.loads(p.read_text(encoding='utf-8'))

def row(d,key,t):
    return next(r for r in d['meshes'][key]['rows'] if abs(r['time_s']-t)<1e-5)

def dataset():
    d=read('screening/local_refinement_summary_round24.json')
    if d['status'] not in ('complete','passed'):raise RuntimeError('Local refinement is incomplete or its integrity audit failed')
    for key,m in d['meshes'].items():
        assert len(m['rows'])==15,(key,'Expected seven primary and eight accepted-node observations')
    return d

def figure10():
    d=dataset();old=read('screening/mesh_verification_summary_round23.json')
    keys=[k for k in STYLES if k in d['meshes']]
    nradial=2+len([k for k in keys if 'A10' not in k])
    labels=['C','F']+keys;x=np.arange(len(labels))
    times=[0.,60.,300.,1800.,7200.,146118.72146]
    titles=['Immediate recharge','After 1 min','After 5 min',
            'After 30 min','After 2 h','After 40.59 h']
    fig,axs=plt.subplots(3,2,figsize=(180*MM,196*MM))
    fig.subplots_adjust(left=.12,right=.98,bottom=.155,top=.94,wspace=.36,hspace=.77)
    plotted=[]
    for ax,t,title,letter in zip(axs.flat,times,titles,'abcdef'):
        rr=[row(old,k,t) for k in ['coarse','fine']]+[row(d,k,t) for k in keys]
        for key,c in [('A',BLUE),('B',ORANGE)]:
            yy=[r[key] for r in rr]
            ax.plot(x[:nradial],yy[:nradial],'-o',color=c,label='History '+key,markersize=3.7)
            ax.plot(x[nradial:],yy[nradial:],'D',mfc='white',mec=c,markersize=4.1)
        ax.axvline(nradial-.5,color=GREY,lw=.6,ls=':')
        ax.set_xticks(x,labels,rotation=25 if len(labels)>6 else 0)
        ax.set_xlim(-.4,len(labels)-.4);ax.set_xlabel('Pore discretization')
        ax.set_ylabel('First-plasticity pressure (MPa)')
        ax.margins(y=.18);grid(ax);panel(ax,letter,title)
        plotted.append({'time_s':t,'rows':rr})
    axs[0,0].legend(loc='best',fontsize=FS_LEGEND)
    fig.text(.5,.055,'C/F: global grids; '+' → '.join(k for k in keys if 'A10' not in k)+': local radial refinement.',
             ha='center',fontsize=FS_NOTE,color=GREY)
    fig.text(.5,.021,'Open diamonds: angular controls. Every mesh repeats the complete preparation.',
             ha='center',fontsize=FS_NOTE,color=GREY)
    DATA['fig10']={'mesh_keys':['coarse','fine']+keys,'samples':plotted}
    export(fig,'fig10_mesh_verification')

def figure11():
    d=dataset();geom=read('screening/local_geometry_independent_round24.json')
    keys=[k for k in STYLES if k in d['meshes']]
    if 'L3' in keys:
        deep=read('screening/local_deep_geometry_independent_round24.json')
        production=read('screening/extra_geometry_L3_round24.json')
        assert deep['status']==production['status']=='passed' and all(deep['checks'].values())
        assert deep['radial_edges_over_a']==production['radial_edges']
        assert len(production['radial_edges'])==int(d['meshes']['L3']['nr'])+1
        geom['families']['L3']={k:deep[k] for k in ('nr','nt','np','radial_edges_over_a','first_shell_width_over_a','geometry')}
    fig,axs=plt.subplots(2,2,figsize=(180*MM,168*MM))
    fig.subplots_adjust(left=.12,right=.98,bottom=.155,top=.93,wspace=.39,hspace=.88)
    a,b,c,e=axs.flat
    radial=[k for k in keys if 'A10' not in k]
    for i,k in enumerate(radial):
        edges=np.asarray(geom['families'][k]['radial_edges_over_a'])
        edges=edges[edges<=2+1e-12];col,marker,ls=STYLES[k]
        a.plot([1,2],[i,i],color=col,lw=.7)
        a.vlines(edges,i-.20,i+.20,color=col,lw=.9)
    a.set_yticks(range(len(radial)),radial);a.set_ylim(len(radial)-.45,-.65)
    a.set_xlim(.98,2.02);a.set_xticks([1,1.25,1.5,1.75,2])
    a.set_xlabel(r'Radial coordinate $\rho/a$');a.set_ylabel('Radial refinement level')
    panel(a,'a','Subdividing the pore-wall zone')
    gaps={}
    for k in keys:
        rr=[r for r in d['meshes'][k]['rows'] if 60-1e-5<=r['time_s']<=1800+1e-5]
        tt=[r['time_s'] for r in rr];yy=[r['A']-r['B'] for r in rr]
        col,marker,ls=STYLES[k];b.plot(tt,yy,color=col,marker=marker,ls=ls,label=k,ms=3.4)
        gaps[k]=rr
    b.axhline(0,color=INK,lw=.7);b.set_xscale('log')
    b.set_xticks([60,120,300,600,1800],['60','120','300','600','1800'])
    b.minorticks_off();b.set_xlabel('Waiting time (s)')
    b.set_ylabel(r'$P_A^*-P_B^*$ (MPa)');grid(b)
    b.legend(loc='upper center',bbox_to_anchor=(.50,-.25),ncol=3,fontsize=FS_LEGEND,
             columnspacing=.8,handlelength=1.4,borderaxespad=0)
    panel(b,'b','Sampled ranking differences')
    pairs=list(zip(radial[:-1],radial[1:]))+[('L1','L1A10')]
    if 'L2A10' in keys:pairs.append(('L2','L2A10'))
    shifts={}
    for j,(k0,k1) in enumerate(pairs):
        t0={round(r['time_s'],6):r for r in d['meshes'][k0]['rows']}
        t1={round(r['time_s'],6):r for r in d['meshes'][k1]['rows']}
        assert set(t0)==set(t1) and len(t0)==15,(k0,k1,'Incomplete matched sample set')
        tt=sorted(t0);actual_times=[t0[t]['time_s'] for t in tt];xx=np.asarray(actual_times)+1
        yp=[max(abs(t1[t][h]-t0[t][h]) for h in ['A','B']) for t in tt]
        yg=[abs((t1[t]['A']-t1[t]['B'])-(t0[t]['A']-t0[t]['B'])) for t in tt]
        col,marker,ls=STYLES[k1]
        label=k0+' → '+k1
        for ax,yy in [(c,yp),(e,yg)]:ax.plot(xx,yy,color=col,marker=marker,ls=ls,label=label,ms=3)
        shifts[label]={'times_s':actual_times,'maximum_individual_shift_MPa':yp,'gap_shift_MPa':yg}
    for ax in [c,e]:
        ax.set_xscale('log');ax.set_yscale('log');ax.set_xticks([1,301,7201,146119.72146],['0','5 min','2 h','40.6 h'])
        ax.axhline(.1,color=INK,ls=':',lw=.9);ax.set_xlabel('Waiting time');grid(ax)
        ax.minorticks_off()
    c.set_ylabel('Largest A/B threshold shift (MPa)')
    e.set_ylabel('Ranking-gap shift (MPa)')
    c.legend(loc='lower left',fontsize=FS_LEGEND,handlelength=1.6)
    panel(c,'c','Absolute-pressure sensitivity');panel(e,'d','History-contrast sensitivity')
    fig.text(.5,.044,'Dotted horizontal lines: the declared 0.1 MPa numerical-resolution target.',ha='center',fontsize=FS_NOTE,color=GREY)
    fig.text(.5,.013,'Markers are computed readouts; connecting lines do not locate exact crossings.',ha='center',fontsize=FS_NOTE,color=GREY)
    DATA['fig11']={'radial_geometry':geom['families'],'gap_samples':gaps,'pair_shifts':shifts,'criterion_MPa':.1}
    export(fig,'fig11_local_refinement')

def intervals(rr):
    ia=(max(r['B'] for r in rr),min(r['A'] for r in rr))
    ib=(max(r['A'] for r in rr),min(r['B'] for r in rr))
    for k,(lo,hi) in [('A',ia),('B',ib)]:
        if lo<hi:return {'favored_history':k,'lo':lo,'hi':hi,'nonempty':True}
    return {'favored_history':None,'lo':None,'hi':None,'nonempty':False}

def figure13():
    d=dataset();keys=[k for k in STYLES if k in d['meshes']]
    finalkeys=[k for k in keys if k!='R0']
    times=[0.,60.,300.,1800.,7200.,146118.72146]
    labels=['0','1 min','5 min','30 min','2 h','40.59 h']
    fig,(a,b)=plt.subplots(1,2,figsize=(180*MM,138*MM))
    fig.subplots_adjust(left=.12,right=.98,bottom=.27,top=.88,wspace=.33)
    samples=[];shared=[]
    mesh_offsets=np.linspace(-.13,.13,len(finalkeys))
    for i,t in enumerate(times):
        rr=[row(d,k,t) for k in finalkeys];samples.append(rr)
        for hist,col,off in [('A',BLUE,-.19),('B',ORANGE,.19)]:
            vals=[r[hist] for r in rr]
            a.plot([min(vals),max(vals)],[i+off,i+off],color=col,lw=1)
            for k,r,offset in zip(finalkeys,rr,mesh_offsets):
                a.plot(r[hist],i+off+offset,STYLES[k][1],mfc='white' if 'A10' in k else col,mec=col,ms=4.4)
        interval=intervals(rr);shared.append(dict(time_s=t,**interval))
        if interval['nonempty']:
            lo,hi=interval['lo'],interval['hi'];col=GREEN if interval['favored_history']=='A' else PURPLE
            b.plot([lo,hi],[i,i],color=col,lw=4,solid_capstyle='butt')
            b.plot([lo,hi],[i,i],'o',mfc='white',mec=col,ms=4.6)
            b.text((lo+hi)/2,i-.21,f"{interval['favored_history']}: ({lo:.2f}, {hi:.2f})",ha='center',va='bottom',fontsize=FS_ANNOTATION)
        else:b.text(21,i,'No common interval',ha='center',fontsize=FS_ANNOTATION,color=ORANGE)
    for ax in [a,b]:
        ax.set_yticks(range(len(times)),labels);ax.set_ylim(len(times)-.45,-.65)
        ax.set_xlim(7,33);ax.set_xlabel('Pressure (MPa)');ax.grid(axis='x',color='#D8DEE4',lw=.45)
    a.set_ylabel('Waiting time');a.legend(handles=[Line2D([0],[0],color=BLUE,label='A'),Line2D([0],[0],color=ORANGE,label='B')],ncol=2,loc='upper left')
    panel(a,'a','Thresholds after local refinement');panel(b,'b','Common pressure intervals')
    mesh_handles=[Line2D([],[],marker=STYLES[k][1],ls='none',mec=INK,
                         mfc='white' if 'A10' in k else INK,label=k) for k in finalkeys]
    fig.legend(handles=mesh_handles,loc='center',bbox_to_anchor=(.5,.151),ncol=len(finalkeys),
               fontsize=FS_LEGEND,handlelength=1,columnspacing=1.5)
    fig.text(.5,.079,'Vertical offsets separate mesh symbols. Green favors A and purple favors B.',ha='center',fontsize=FS_NOTE,color=GREY)
    fig.text(.5,.025,'Shared finite-mesh intervals are reported separately from convergence of their endpoints.',ha='center',fontsize=FS_NOTE,color=GREY)
    DATA['fig13']={'comparison_meshes':finalkeys,'mesh_samples':samples,'intervals':shared}
    export(fig,'fig13_operating_intervals')

if __name__=='__main__':
    figure10();figure11();figure13()
    (OUT/'local_refinement_source_data_round24.json').write_text(json.dumps({
        'source_sha256':SOURCES,'data':DATA,'statistics':'Deterministic FE simulations; no statistical error bars.',
        'export':{'width_mm':180,'raster_dpi':600,'text_font':'Times New Roman','math_font':'STIX'}},indent=2),encoding='utf-8')
    print('Exported Figures10,11,13 from completed local-refinement data.')
