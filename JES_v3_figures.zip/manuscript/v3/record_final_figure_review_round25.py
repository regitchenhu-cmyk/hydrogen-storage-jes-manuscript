"""Record the completed, direct visual inspection of the round-25 exports.

This is a review record, not an automated assertion that arbitrary new figures
look correct. Run only after inspecting every preview in the export directory.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'manuscript/figures_final'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

NOTES = {
    'fig01_protocol': 'Cylinder, pore and pressure/pulse stages are legible. Times New Roman and STIX symbols are consistent. The surrounding-polymer label fits; rho denotes the radial position at 8a. Schematic scale and stage durations are explicit.',
    'fig02_thresholds': 'All three panels are legible. The negative reference-gap annotation has been moved clear of the x-axis by extending the lower y limit. The five-mesh panel contains only discrete, horizontally offset markers at 0, 122.716 s and 2 h; no fitted crossing is drawn. Its legend and footer are separate. Reference curves, units and the shaded +/-1 MPa band are visible.',
    'fig03_spatial_yield': 'Both angular profiles and their renewed-yield stars remain clear. Region M and region H use standard prose labels; radial units, normalization and the reference-mesh note are readable.',
    'fig04_interventions': 'The threshold-difference histories and 40 s mechanism comparison are clear. Macro recovery off, Pore recovery off and Gas exchange off are legible in the two-column legend without overlap.',
    'fig05_recovery_exchange': 'All four panels are clear. The Gas exchange off categorical tick is correctly rendered. The uptake-to-release annotation and the four endpoint threshold labels are separated from curves and axes.',
    'fig06_interactions': 'Interaction bars, axis labels and numerical annotations are legible. The categorical tick reads Remaining change v_0, matching the manuscript definition, and does not collide with adjacent labels.',
    'fig07_spatial_memory': 'Spatial profiles and retained plastic-strain-difference curves are clear. Mesh C and Mesh F are identified explicitly; the retained-percentage annotation remains readable.',
    'fig08_pressure_intervals': 'Individual thresholds and shared pressure intervals are clear. The explicit L1, L2, L3 and L1A10 marker legend replaces the old figure-number reference. Interval endpoints and both No common interval labels are legible.',
    'figS1_verification': 'Both analytical/numerical benchmark panels are clear. Error units, refinement axes, slope reference and diffusion-series legend are readable.',
    'figS2_controls': 'Control bars and freezing-effect sensitivity bars are clear. Both top legends are separate from panel titles; categorical labels fit.',
    'figS3_mesh_thresholds': 'All six pressure panels are clear at the final width. C, F, R0, L1, L2, L3 and angular-control symbols are readable, with the two-line explanatory footer separated from axes.',
    'figS4_local_refinement': 'Four panels are clear. Radial-grid sketch, threshold-difference trajectories, absolute shifts and difference shifts retain readable axes and legends. The numerical-resolution line is explicit. The revised footer reads Markers are computed points; connecting lines do not locate exact crossings, and fits without clipping.',
    'figS5_transient_exchange': 'All four transport panels are clear. Quasi-steady comparisons use consistent terminology; base/half-step legends, preparation-inventory bars and the 288-element check are readable.',
}

source_path = OUT / 'final_figure_source_data_round25.json'
source = json.loads(source_path.read_text(encoding='utf8'))
assert set(NOTES) == set(source['export'])
for stem in NOTES:
    assert sha(OUT / f'{stem}_preview.png') == source['export'][stem]['preview_sha256']

source['status'] = 'rendered_and_visually_reviewed'
source['visual_review_file'] = 'FIGURE_VISUAL_REVIEW_ROUND25.json'
source_path.write_text(json.dumps(source, indent=2), encoding='utf8')
report = {
    'status': 'passed',
    'method': 'Direct inspection of every final PNG preview at readable resolution; array/format verification is recorded separately.',
    'new_mechanics_solves': False,
    'figure_count': len(NOTES),
    'source_extract_sha256': sha(source_path),
    'figures': [dict(stem=stem, status='passed', note=note,
                     preview_sha256=sha(OUT / f'{stem}_preview.png'),
                     pdf_sha256=sha(OUT / f'{stem}.pdf')) for stem, note in NOTES.items()],
}
(OUT / 'FIGURE_VISUAL_REVIEW_ROUND25.json').write_text(json.dumps(report, indent=2), encoding='utf8')
print(json.dumps({'visual_status': report['status'], 'reviewed_figures': len(NOTES)}))
