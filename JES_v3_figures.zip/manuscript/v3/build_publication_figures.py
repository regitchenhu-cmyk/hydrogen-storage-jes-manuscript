"""Final-size publication figures from archived solver outputs; no solver runs."""
from pathlib import Path
import json, hashlib, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib.ticker import NullFormatter
from matplotlib.transforms import ScaledTranslation

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'manuscript'/'figures_v3';OUT.mkdir(parents=True,exist_ok=True)
SRC={};DATA={}
BLUE='#0072B2';ORANGE='#D55E00';INK='#273340';GREY='#87929D'
PURPLE='#8A6AAB';GREEN='#17857A'
MC={'none':INK,'macro':ORANGE,'micro':PURPLE,'gas':GREEN}
ML={'none':'All active','macro':'Macro frozen','micro':'Pore frozen','gas':'Exchange frozen'}
MM=1/25.4
FS_LABEL=10.5;FS_TICK=9.5;FS_LEGEND=9.5;FS_PANEL=12;FS_TITLE=10.5
FS_ANNOTATION=9.5;FS_NOTE=9
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman'],'font.size':FS_ANNOTATION,'axes.labelsize':FS_LABEL,
 'xtick.labelsize':FS_TICK,'ytick.labelsize':FS_TICK,'legend.fontsize':FS_LEGEND,
 'axes.titlesize':FS_TITLE,'axes.titleweight':'normal','axes.linewidth':.7,
 'axes.spines.top':False,'axes.spines.right':False,'xtick.major.width':.7,
 'ytick.major.width':.7,'xtick.major.size':3,'ytick.major.size':3,
 'lines.linewidth':1.35,'lines.markersize':3.5,'legend.frameon':False,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
 'savefig.facecolor':'white','figure.facecolor':'white','mathtext.fontset':'stix','mathtext.fallback':'stix'})

def read(rel):
 p=ROOT/rel;SRC[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
 return json.loads(p.read_text(encoding='utf-8'))
ret=read('mechanics/viscoelastic_summary_round21.json')
attr=read('screening/mechanism_attribution_round22.json')
ev=read('manuscript/jes_review/existing_evidence.json')
paths=read('mechanics/viscoelastic_cylinder_paths_round21.json')
holds={k:read(f'mechanics/mechanism_{k}_fine_holds_round22.json') for k in ['none','gas']}
fine=ret['tables']['main_fine'];coarse=ret['tables']['main_coarse']

def panel(ax,letter,title):
 title_artist=ax.set_title(title,loc='left',x=0,pad=11,fontsize=FS_TITLE)
 title_artist.set_transform(title_artist.get_transform()+ScaledTranslation(20/72,0,ax.figure.dpi_scale_trans))
 ax.annotate(f'({letter})',xy=(0,1),xycoords='axes fraction',xytext=(0,11),textcoords='offset points',
  fontweight='bold',fontsize=FS_PANEL,va='baseline',ha='left',annotation_clip=False)
def grid(ax):ax.grid(axis='y',color='#D8DEE4',lw=.45,zorder=0)
def export(fig,name):
 # Preserve the declared physical canvas; layout is verified on this exact size.
 fig.savefig(OUT/(name+'.pdf'))
 fig.savefig(OUT/(name+'.svg'))
 fig.savefig(OUT/(name+'.png'),dpi=600)
 fig.savefig(OUT/(name+'.tiff'),dpi=600,pil_kwargs={'compression':'tiff_lzw'})
 fig.savefig(OUT/(name+'_preview.png'),dpi=170)
 plt.close(fig)
def wait_axis(ax,long=True):
 ax.set_xscale('symlog',linthresh=1)
 ticks=[0,10,300,7200]+([ret['horizon_seconds']] if long else [])
 labs=['0','10 s','5 min','2 h']+(['40.6 h'] if long else [])
 ax.set_xticks(ticks,labs);ax.set_xlim(-.15,2.3e5 if long else 1e4)
 ax.set_xlabel('Waiting time');grid(ax)

def figure1():
 fig=plt.figure(figsize=(180*MM,148*MM))
 gs=fig.add_gridspec(2,2,height_ratios=[1,1.15],left=.08,right=.97,bottom=.11,top=.94,wspace=.33,hspace=.30)
 a=fig.add_subplot(gs[0,0]);a.set_xlim(0,10);a.set_ylim(0,6.5);a.axis('off')
 panel(a,'a','Supported liner and end fixture')
 a.add_patch(Rectangle((1.0,2.1),7.3,1.3,facecolor='#D6DCE1',edgecolor=GREY,lw=.8))
 a.add_patch(Rectangle((1.0,1.65),7.3,.45,facecolor='#C8E5F3',edgecolor=BLUE,lw=.8))
 a.text(4.65,2.75,'Elastic shell  ·  8 mm',ha='center',va='center')
 a.text(4.65,1.87,'Polymer liner  ·  1 mm',ha='center',va='center',fontsize=FS_ANNOTATION)
 a.plot([1,8.3],[2.1,2.1],color=INK,lw=1.1,ls=(0,(2,1)))
 for x in [2.2,4.5,6.8]:a.annotate('',(x,1.62),(x,.95),arrowprops={'arrowstyle':'-|>','lw':.9,'color':INK})
 a.text(4.65,.5,r'Vessel pressure $P(t)$',ha='center')
 a.annotate('',(1,1.87),(.1,1.87),arrowprops={'arrowstyle':'-|>','color':ORANGE,'lw':1.5})
 a.annotate('',(8.3,1.87),(9.3,1.87),arrowprops={'arrowstyle':'-|>','color':ORANGE,'lw':1.5})
 a.text(4.65,4.45,'Inner radius 150 mm; half-length 50 mm',ha='center',fontsize=FS_ANNOTATION)
 a.text(4.65,5.2,r'Independent axial traction $Q(t)$',ha='center',color=ORANGE)
 a.annotate('Normal support + tangential slip',xy=(1.0,2.1),xytext=(4.65,3.75),ha='center',fontsize=FS_ANNOTATION,
  arrowprops={'arrowstyle':'-','lw':.7,'color':GREY})
 a.plot(7.6,1.99,'o',ms=3,color=INK)
 b=fig.add_subplot(gs[0,1]);b.set_xlim(-1.9,2.3);b.set_ylim(-1.5,1.9);b.set_aspect('equal');b.axis('off')
 panel(b,'b','Local gas-filled pore')
 b.add_patch(Circle((0,0),1.15,facecolor='#EAF3F8',edgecolor=BLUE,lw=1))
 b.add_patch(Circle((0,0),.48,facecolor='white',edgecolor=INK,lw=1))
 for ang in [0,np.pi/2,np.pi,3*np.pi/2]:
  xy=np.array([np.cos(ang),np.sin(ang)])
  b.annotate('',xy*.83,xy*1.4,arrowprops={'arrowstyle':'-|>','lw':.9,'color':INK})
 b.text(0,0,r'$p_g V=N$',ha='center',va='center',fontsize=FS_ANNOTATION)
 b.text(1.22,.85,r'$a=10\ \mu$m',fontsize=FS_ANNOTATION)
 b.text(1.23,.38,r'$R=8a$',fontsize=FS_ANNOTATION)
 b.text(0,1.65,r'Macro stress $\boldsymbol{\Sigma}(t)$',ha='center')
 b.text(0,-1.7,r'Bath $\pi_b(t)$  $\rightleftarrows$  pore inventory $N$',ha='center',fontsize=FS_ANNOTATION)
 inner=gs[1,:].subgridspec(2,1,hspace=.1,height_ratios=[1,1])
 p=fig.add_subplot(inner[0]);q=fig.add_subplot(inner[1],sharex=p)
 panel(p,'c','Common pressure program and two preparation pulses')
 x=np.arange(8);p.plot(x,[.1,35,35,.1,.1,.1,.1,35],'-o',color=INK,ms=2.7)
 p.set_ylabel('$P$ (MPa)');p.set_ylim(-3,40);p.set_yticks([0,35]);p.tick_params(labelbottom=False)
 for amp,c,lab in [(10,BLUE,'A: −10 MPa'),(40,ORANGE,'B: −40 MPa')]:
  q.plot(x,[0,0,0,0,-amp,0,0,0],'-o',color=c,ms=2.7,label=lab)
 q.set_ylabel('$Q$ (MPa)');q.set_ylim(-46,6);q.set_yticks([-40,-10,0]);q.legend(loc='lower left',ncol=2,fontsize=FS_LEGEND)
 for ax in [p,q]:
  ax.set_xlim(-.1,7.1)
  ax.axvspan(5,6,facecolor='#E9EDF1',zorder=-2);ax.axvspan(6,7,facecolor='#E3F1EC',zorder=-2)
  for xx in range(1,7):ax.axvline(xx,color='#C9D1D8',lw=.5,ls=':')
 tw=paths['transport_clock']['tau_wall_h2_D_s'];tp=paths['transport_clock']['tau_p_s']
 stages=['Fill\n101.5 h','Hold\n50.7 h','Release\n1.81 s','Pulse in\n1.81 s','Pulse out\n1.81 s','Wait\n'+r'$t_w$','Recharge\n18.14 s']
 q.set_xticks(np.arange(7)+.5,stages,fontsize=FS_TICK);q.tick_params(axis='x',length=0)
 fig.text(.53,.012,'Equal-width stages; durations are labelled. Schematics are not to scale.',ha='center',fontsize=FS_NOTE,color=GREY)
 DATA['fig01']={'tau_w_s':tw,'tau_p_s':tp,'protocol':'same pressure; different axial pulse amplitudes'}
 export(fig,'fig01_protocol')

def figure2():
 fig,axs=plt.subplots(1,2,figsize=(180*MM,86*MM));fig.subplots_adjust(left=.1,right=.98,bottom=.2,top=.84,wspace=.42)
 rows=ev['material_point']['two_branch_exact_ode']['convergence'];dt=np.array([r['dt'] for r in rows])
 a=axs[0]
 for key,c,mark,label in [('creep_strain_error',BLUE,'o','Creep strain'),('relaxation_stress_error',ORANGE,'s','Relaxation stress / $E_0$')]:
  vals=np.array([r[key] for r in rows]);a.loglog(dt,vals,'-'+mark,color=c,label=label)
 a.loglog(dt,rows[0]['creep_strain_error']*dt/dt[0],'--',color=GREY,lw=.8,label='First-order slope')
 a.set_xlabel('Time increment (s)');a.set_ylabel('Absolute dimensionless error');a.legend(fontsize=FS_LEGEND,loc='upper left')
 a.set_xticks([3.5,7,14,28],['3.5','7','14','28']);panel(a,'a','Exact viscoelastic time evolution');grid(a)
 b=axs[1];rs=ev['diffusion']['checks']['FV_convergence']
 for chi,c,mark in [(.01,BLUE,'o'),(.1,ORANGE,'s'),(.5,GREEN,'^')]:
  rr=[r for r in rs if r['chi']==chi]
  b.loglog([r['n'] for r in rr],[r['max_error'] for r in rr],'-'+mark,color=c,label=f'$Dt/h^2={chi:g}$')
 b.set_xticks([40,80,160],['40','80','160']);b.set_xlabel('Finite-volume cells');b.set_ylabel('Maximum concentration error')
 b.legend(fontsize=FS_LEGEND);panel(b,'b','Independent diffusion discretization');grid(b)
 for ax in axs:ax.xaxis.set_minor_formatter(NullFormatter())
 DATA['fig02']={'viscoelastic':rows,'diffusion':rs};export(fig,'fig02_verification')

def figure3():
 fig,axs=plt.subplots(1,2,figsize=(180*MM,91*MM));fig.subplots_adjust(left=.09,right=.98,bottom=.2,top=.83,wspace=.35)
 a,b=axs
 for key,c,label in [('A',BLUE,'History A'),('B',ORANGE,'History B')]:
  a.plot([r['time_s'] for r in coarse],[r[key] for r in coarse],':',color=c,alpha=.65)
  a.plot([r['time_s'] for r in fine],[r[key] for r in fine],'-o',color=c,label=label)
 a.set_ylim(0,36);a.set_ylabel('Recharging threshold (MPa)');wait_axis(a);a.legend(loc='lower left')
 panel(a,'a','Re-pressurization thresholds')
 b.axhspan(-1,1,color='#E5E9ED',zorder=-3);b.axhline(0,c=GREY,lw=.7)
 for tab,c,ls,lab in [(coarse,GREY,':','Coarse'),(fine,INK,'-o','Fine')]:b.plot([r['time_s'] for r in tab],[r['gap'] for r in tab],ls,color=c,label=lab)
 wait_axis(b);b.set_ylim(-3,13);b.set_ylabel(r'Threshold difference $P_A^*-P_B^*$ (MPa)');b.legend(loc='upper right')
 panel(b,'b','Double reversal of the ranking')
 for t,off in [(0,(6,4)),(300,(0,-13)),(7200,(-13,10)),(ret['horizon_seconds'],(-20,10))]:
  rr=next(r for r in fine if r['time_s']==t);b.annotate(f"{rr['gap']:+.2f}",(t,rr['gap']),xytext=off,textcoords='offset points',fontsize=FS_ANNOTATION,fontweight='bold')
 fig.text(.5,.025,'Solid / markers: fine mesh. Dotted: coarse mesh. Lines connect computed samples.',ha='center',fontsize=FS_NOTE,color=GREY)
 DATA['fig03']={'fine':fine,'coarse':coarse};export(fig,'fig03_thresholds')

def figure5():
 fig,axs=plt.subplots(1,2,figsize=(180*MM,106*MM));fig.subplots_adjust(left=.09,right=.98,bottom=.22,top=.78,wspace=.38)
 a,b=axs
 for mode in ['none','macro','micro','gas']:
  rr=attr['normal_readout']['fine'][mode]
  a.plot([r['wait_seconds'] for r in rr],[r['gap_MPa'] for r in rr],'-o',color=MC[mode],label=ML[mode])
 a.axhline(0,c=GREY,lw=.7);a.set_xscale('log');a.set_xlim(32,9000);a.set_ylim(-3.5,10)
 a.set_xticks([40,300,1800,7200],['40 s','5 min','30 min','2 h']);a.set_xlabel('Waiting time');a.set_ylabel(r'$P_A^*-P_B^*$ (MPa)')
 panel(a,'a','Freeze one waiting mechanism');a.legend(loc='lower left',bbox_to_anchor=(0,1.16),ncol=2,fontsize=FS_LEGEND,columnspacing=1.2);grid(a)
 eff=attr['waiting_single_deletion_effects']['fine'];x=np.arange(3);w=.33
 for key,dx,c,lab in [('delta_PA_MPa',-w/2,BLUE,'History A'),('delta_PB_MPa',w/2,ORANGE,'History B')]:
  vals=[next(r for r in eff[n] if r['wait_seconds']==40)[key] for n in ['macro','micro','gas']]
  b.bar(x+dx,vals,w,color=c,label=lab,zorder=3)
  for ii,(xx,v) in enumerate(zip(x+dx,vals)):
   label_x=xx+((-.045 if dx<0 else .045) if ii==2 else 0)
   b.text(label_x,v+(.2 if v>=0 else -.2),f'{v:+.2f}',ha='center',va='bottom' if v>=0 else 'top',fontsize=FS_ANNOTATION)
 b.axhline(0,c=GREY,lw=.7);b.set_ylim(-4.3,9.2);b.set_xticks(x,['Macro','Pore','Exchange']);b.set_xlabel('Frozen mechanism')
 b.set_ylabel('Threshold change at 40 s (MPa)');b.legend(loc='upper right',fontsize=FS_LEGEND);grid(b);panel(b,'b','History-specific early effects')
 fig.text(.5,.035,'Fine mesh. All evolution rates are restored during the recharging test.',ha='center',fontsize=FS_NOTE,color=GREY)
 DATA['fig05']={'gaps':attr['normal_readout']['fine'],'effects':eff};export(fig,'fig05_interventions')

def trajectory(mode,amp):
 d=holds[mode][str(amp)];rr=d['records'];t0=d['origin']['initial_intervention']['macro']['time_seconds'];n0=d['checkpoints'][0]['N']
 return {'t':np.array([r['global_time_seconds']-t0 for r in rr]),'inventory':np.array([r['N']/n0 for r in rr]),
  'driving':np.array([r['q_MPa']-r['p_MPa'] for r in rr]),'hoop':np.array([r['macro']['remote_diagonal_Pa'][2]/1e6 for r in rr])}

def figure6():
 fig,axs=plt.subplots(2,2,figsize=(180*MM,145*MM));fig.subplots_adjust(left=.1,right=.98,bottom=.11,top=.93,wspace=.4,hspace=.54)
 for amp,c,ls,lab in [(10,BLUE,'-','A'),(40,ORANGE,'--','B')]:
  d=trajectory('none',amp)
  for ax,key in zip([axs[0,0],axs[0,1],axs[1,0]],['hoop','inventory','driving']):
   ax.plot(d['t'],d[key],ls,color=c,label=lab);ax.set_xscale('log');ax.set_xlim(.2,8000)
   ax.set_xticks([1,10,100,1000,7200],['1','10','100','1000','7200']);ax.set_xlabel('Waiting time (s)');grid(ax)
  DATA['fig06_'+lab]={k:v.tolist() for k,v in d.items()}
 axs[0,0].set_ylabel('Remote hoop stress (MPa)');axs[0,0].set_ylim(-7,1);axs[0,0].legend(title='History',ncol=2,fontsize=FS_LEGEND,title_fontsize=FS_LEGEND);panel(axs[0,0],'a','Macroscopic stress recovery')
 axs[0,1].axhline(1,c=GREY,lw=.7);axs[0,1].set_ylabel('Inventory / prepared inventory');panel(axs[0,1],'b','Pore inventory')
 axs[1,0].axhline(0,c=GREY,lw=.7);axs[1,0].set_ylabel('Exchange driving pressure (MPa)');panel(axs[1,0],'c','Uptake changes to release')
 d=trajectory('none',10);jj=np.flatnonzero((d['driving'][:-1]>0)&(d['driving'][1:]<=0))[0]
 axs[1,0].annotate('A: ≈23 min',xy=(d['t'][jj],0),xytext=(8,-.24),fontsize=FS_ANNOTATION,arrowprops={'arrowstyle':'->','color':GREY,'lw':.8})
 ax=axs[1,1]
 for j,(key,c,label) in enumerate([('PA_MPa',BLUE,'A'),('PB_MPa',ORANGE,'B')]):
  full=next(r for r in attr['normal_readout']['fine']['none'] if r['wait_seconds']==7200)[key]
  frozen=next(r for r in attr['normal_readout']['fine']['gas'] if r['wait_seconds']==7200)[key]
  ax.plot([0,1],[frozen,full],'-o',color=c,label=label)
  for xx,v in [(0,frozen),(1,full)]:
   dy=((-13 if j==0 else 8) if xx==0 else (8 if j==0 else -13))
   ax.annotate(f'{v:.2f}',(xx,v),xytext=(0,dy),textcoords='offset points',ha='center',fontsize=FS_ANNOTATION,color=c)
 ax.set_xlim(-.25,1.25);ax.set_ylim(10,31);ax.set_xticks([0,1],['Exchange frozen','All active']);ax.set_ylabel('Threshold after 2 h (MPa)');grid(ax);panel(ax,'d','Exchange restores both thresholds')
 export(fig,'fig06_recovery_exchange')

def figure7():
 fig,axs=plt.subplots(1,2,figsize=(180*MM,112*MM),gridspec_kw={'width_ratios':[1.05,1]})
 fig.subplots_adjust(left=.19,right=.97,bottom=.19,top=.86,wspace=.7)
 facts=attr['coarse_factorial'];sets=[[],['macro'],['micro'],['gas'],['macro','micro'],['macro','gas'],['micro','gas'],['macro','micro','gas']]
 labels=['None','Macro','Pore','Exchange','Macro + pore','Macro + exchange','Pore + exchange','All three']
 arr=np.array([[next(r for r in f['coalitions'] if set(r['active'])==set(s))['change'] for f in facts] for s in sets])
 a=axs[0];im=a.imshow(arr,cmap='RdBu',vmin=-10,vmax=10,aspect='auto');a.set_yticks(range(8),labels);a.set_xticks([0,1],['10–300 s','300–7200 s']);a.set_ylabel('Active waiting mechanisms');a.set_xlabel('Waiting interval')
 for i in range(8):
  for j in range(2):a.text(j,i,f'{arr[i,j]:+.2f}' if abs(arr[i,j])>=.005 else '0.00',ha='center',va='center',color='white' if abs(arr[i,j])>5.5 else INK,fontsize=FS_ANNOTATION)
 panel(a,'a','All eight combinations')
 cb=fig.colorbar(im,ax=a,orientation='horizontal',pad=.18,shrink=.9,aspect=20);cb.set_label('Change in threshold difference (MPa)',fontsize=FS_LABEL);cb.ax.tick_params(labelsize=FS_TICK)
 b=axs[1];names=['Macro','Pore','Exchange','Bath / test'];y=np.arange(4)
 for j,(fact,c,lab) in enumerate(zip(facts,[BLUE,ORANGE],['10–300 s','300–7200 s'])):
  vals=[fact['shapley_MPa'][x] for x in ['macro','micro','gas']]+[fact['all_waiting_frozen_bath_readout_change_MPa']]
  b.barh(y+(j-.5)*.32,vals,height=.29,color=c,label=lab,zorder=3)
 b.set_yticks(y,names);b.invert_yaxis();b.axvline(0,color=GREY,lw=.7);b.set_xlim(-7.2,3.3);b.set_xlabel('Allocated change (MPa)');b.legend(loc='lower left',fontsize=FS_LEGEND);b.grid(axis='x',color='#D8DEE4',lw=.45)
 panel(b,'b','Shapley allocation');DATA['fig07']={'coalition_changes':arr.tolist(),'factorial':facts};export(fig,'fig07_interactions')

def figure9():
 fig,axs=plt.subplots(1,2,figsize=(180*MM,96*MM));fig.subplots_adjust(left=.09,right=.98,bottom=.2,top=.74,wspace=.4)
 a,b=axs;rows=ev['spectral_controls']['rows'];times=[0,300,7200,146118.72146];x=np.arange(4);w=.23
 for j,(case,c,lab) in enumerate([('main_coarse',BLUE,'Reference'),('near_yield_coarse',PURPLE,'Alternative'),('elastic_coarse',GREY,'Elastic–plastic')]):
  vals=[next(r['gap'] for r in rows if r['case']==case and abs(r['time_s']-t)<.01) for t in times]
  a.bar(x+(j-1)*w,vals,w,color=c,label=lab,zorder=3)
 a.axhline(0,c=INK,lw=.7);a.set_ylim(-2.5,23);a.set_xticks(x,['0','5 min','2 h','40.6 h']);a.set_xlabel('Waiting time (discrete samples)');a.set_ylabel('Threshold difference (MPa)');a.legend(loc='lower left',bbox_to_anchor=(0,1.18),ncol=2,columnspacing=1.2,fontsize=FS_LEGEND);grid(a);panel(a,'a','Separately prepared spectra')
 # Values are recomputed from matched raw intervention results, not inferred from plot.
 maxes={'time':[],'space':[]};nr=attr['normal_readout']
 for mode in ['macro','micro','gas']:
  coarse_effect={r['wait_seconds']:r['delta_gap_MPa'] for r in attr['waiting_single_deletion_effects']['coarse'][mode]}
  fine_effect={r['wait_seconds']:r['delta_gap_MPa'] for r in attr['waiting_single_deletion_effects']['fine'][mode]}
  maxes['space'].append(max(abs(v-coarse_effect[t]) for t,v in fine_effect.items() if t in coarse_effect))
  raw={m:read(f'mechanics/mechanism_{m}_dt2_round22.json')['results'] for m in ['none',mode]}
  def gaps(rr):
   lk={(r['wait_seconds'],r['pulse_MPa']):r['first_reyield']['pressure_MPa'] for r in rr if r['readout']=='normal'}
   return {t:lk[t,-10]-lk[t,-40] for t,amp in lk if amp==-10 and (t,-40) in lk}
  g0,g1=gaps(raw['none']),gaps(raw[mode]);maxes['time'].append(max(abs(g1[t]-g0[t]-coarse_effect[t]) for t in g1 if t in g0 and t in coarse_effect))
 xx=np.arange(3)
 for dx,key,c,lab in [(-.17,'time',GREY,'Time-step halving'),(.17,'space',BLUE,'Pore-mesh refinement')]:b.bar(xx+dx,maxes[key],.31,color=c,label=lab,zorder=3)
 b.set_yscale('log');b.set_ylim(.003,7);b.set_xticks(xx,['Macro','Pore','Exchange']);b.set_xlabel('Frozen mechanism');b.set_ylabel('Maximum paired-effect change (MPa)');b.legend(loc='lower right',bbox_to_anchor=(1,1.18),fontsize=FS_LEGEND);grid(b);panel(b,'b','Discrete sensitivity of interventions')
 DATA['fig09']={'spectral_controls':rows,'maximum_effect_changes':maxes};export(fig,'fig09_controls')

def _historical_three_mesh_intervals_round23():
 d=read('screening/mesh_verification_summary_round23.json')
 if d['status']!='complete':raise RuntimeError('Three-mesh verification is not complete')
 fig,axs=plt.subplots(1,2,figsize=(180*MM,124*MM));fig.subplots_adjust(left=.12,right=.98,bottom=.28,top=.87,wspace=.33)
 a,b=axs;times=[0,60,300,7200,146118.72146];labels=['0','1 min','5 min','2 h','40.59 h'];ints=[];samples=[];purple_shown=False
 for i,t in enumerate(times):
  rr=[next(r for r in d['meshes'][k]['rows'] if abs(r['time_s']-t)<.01) for k in ['coarse','fine','finer']]
  samples.append(rr)
  for key,col,off in [('A',BLUE,-.12),('B',ORANGE,.12)]:
   vals=[r[key] for r in rr];a.plot([min(vals),max(vals)],[i+off,i+off],color=col,lw=1.4)
   for r,marker,fill in zip(rr,['o','o','^'],['white',col,col]):
    a.plot(r[key],i+off,marker,mfc=fill,mec=col,ms=4.6)
  ia=(max(r['B'] for r in rr),min(r['A'] for r in rr))
  ib=(max(r['A'] for r in rr),min(r['B'] for r in rr))
  fav='A' if all(r['A']>r['B'] for r in rr) else 'B' if all(r['B']>r['A'] for r in rr) else 'Mixed'
  lo,hi=ia if fav=='A' else ib
  pair=rr[1:]
  pair_fav='A' if all(r['A']>r['B'] for r in pair) else 'B' if all(r['B']>r['A'] for r in pair) else 'Mixed'
  plo,phi=(max(r['B'] for r in pair),min(r['A'] for r in pair)) if pair_fav=='A' else (max(r['A'] for r in pair),min(r['B'] for r in pair))
  if lo<hi:
   b.plot([lo,hi],[i,i],color=GREEN,lw=5,solid_capstyle='butt');b.plot([lo,hi],[i,i],'o',mfc='white',mec=GREEN,ms=5)
   b.text((lo+hi)/2,i-.2,f'({lo:.2f}, {hi:.2f})',ha='center',va='bottom',fontsize=FS_ANNOTATION)
  elif plo<phi and pair_fav!='Mixed':
   purple_shown=True
   b.plot([plo,phi],[i,i],color=PURPLE,lw=5,solid_capstyle='butt');b.plot([plo,phi],[i,i],'o',mfc='white',mec=PURPLE,ms=5)
   b.text((plo+phi)/2,i-.2,f'({plo:.2f}, {phi:.2f})',ha='center',va='bottom',fontsize=FS_ANNOTATION,color=PURPLE)
  else:b.text(22,i,'No common interval',ha='center',va='center',fontsize=FS_ANNOTATION,color=ORANGE,bbox=dict(facecolor='white',edgecolor='none',pad=1),zorder=5)
  ints.append({'t_s':t,'favored_history':fav,'lo':lo,'hi':hi,'nonempty':lo<hi,
               'fine_pair':{'favored_history':pair_fav,'lo':plo,'hi':phi,'nonempty':plo<phi and pair_fav!='Mixed'}})
 for ax in axs:
  ax.set_yticks(range(len(times)),labels);ax.set_ylim(len(times)-.5,-.55);ax.set_xlim(9,33);ax.set_xlabel('Pressure (MPa)');ax.grid(axis='x',color='#D8DEE4',lw=.45)
 a.set_ylabel('Waiting time');panel(a,'a','Thresholds on three meshes');panel(b,'b','Shared distinguishing intervals')
 a.legend(handles=[Line2D([0],[0],color=BLUE,label='A'),Line2D([0],[0],color=ORANGE,label='B')],loc='upper left',ncol=2)
 test=next((p for p in [23.,22.] if all(ints[j]['lo']<p<ints[j]['hi'] for j in [0,len(ints)-1])),None)
 if test is None:
  lo=max(ints[j]['lo'] for j in [0,len(ints)-1]);hi=min(ints[j]['hi'] for j in [0,len(ints)-1]);test=round((lo+hi)/2,1)
  if not lo<test<hi:raise RuntimeError('No common illustrative test pressure')
 b.axvline(test,color=INK,ls=':',lw=.8);b.text(test+.4,len(times)-.55,f'{test:g} MPa test',fontsize=FS_ANNOTATION,color=INK)
 fig.text(.5,.14,'Open circle: 80 elements; filled circle: 288; triangle: 768.',ha='center',fontsize=FS_NOTE,color=GREY)
 fig.text(.5,.085,'Green intervals: all three meshes.'+(' Purple interval: the two finer meshes only.' if purple_shown else ''),ha='center',fontsize=FS_NOTE,color=GREY)
 fig.text(.5,.03,'Terminal pressure truncates the same ramp; intervals show agreement of tested meshes.',ha='center',fontsize=FS_NOTE,color=GREY)
 DATA['fig12']={'intervals':ints,'mesh_samples':samples,'illustrative_test_MPa':test};export(fig,'fig12_operating_intervals')

if __name__=='__main__':
 # The local-refinement builder now supplies the operating-interval Figure13.
 for fn in [figure1,figure2,figure3,figure5,figure6,figure7,figure9]:fn()
 (OUT/'publication_source_data.json').write_text(json.dumps({'source_sha256':SRC,'data':DATA,'export':{'width_mm':180,'png_tiff_dpi':600,'font':'Times New Roman','math_font':'STIX','font_pt':FS_ANNOTATION,'typography_pt':{'axes_labels':FS_LABEL,'ticks':FS_TICK,'legend':FS_LEGEND,'panel_letters':FS_PANEL,'panel_titles':FS_TITLE,'annotations':FS_ANNOTATION,'notes':FS_NOTE},'vector_masters':['pdf','svg']},'statistics':'Deterministic simulations. No statistical uncertainty bars.'},indent=2),encoding='utf-8')
 print('Exported 7 figures in PDF, SVG, 600 dpi PNG/TIFF and Python previews.')
